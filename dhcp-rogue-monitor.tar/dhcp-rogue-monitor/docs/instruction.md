# HƯỚNG DẪN THỰC HÀNH BÀI LAB: PHÁT HIỆN MÁY CHỦ DHCP GIẢ MẠO BẰNG DHCP FINGERPRINTING & ARP MONITORING (`dhcp-rogue-monitor`)

---

## 1. Sơ đồ mạng và Phân bổ Địa chỉ (Topology)

| Máy (Container) | Mạng kết nối | Địa chỉ IP & MAC | Vai trò |
| :--- | :--- | :--- | :--- |
| **`dhcpserver`** | `INTERNAL_NET` (`192.168.0.0/24`) | `192.168.0.100`<br>`02:42:c0:a8:00:64` | **ISC DHCP Server hợp lệ** cấp phát Pool `10.10.0.100 - 10.10.0.130`, Gateway `10.10.0.1`, DNS `192.168.0.100`. |
| **`dhcprelay`** | Nối cả 2 mạng (`Dual-Homed`) | `INTERNAL_NET`: `192.168.0.1`<br>`EXTERNAL_NET`: `10.10.0.1` (`02:42:0a:0a:00:01`) | **DHCP Relay + Scapy DHCP/ARP Sensor + Web Dashboard (`:5000`) + TShark/Wireshark**. |
| **`attacker`** | `EXTERNAL_NET` (`10.10.0.0/24`) | `10.10.0.20`<br>`02:42:0a:0a:00:14` | **Kali Rogue DHCP Server** phát tán `DHCPOFFER`/`DHCPACK` giả mạo bằng Scapy. |
| **`client`** | `EXTERNAL_NET` (`10.10.0.0/24`) | *Động qua DHCP*<br>`02:42:0a:0a:00:32` | **Ubuntu Client** xin cấp phát IP qua `dhclient` ở 3 giai đoạn: Baseline, Rogue Attack, và Recovery. |

---

## 2. GIAI ĐOẠN 1: Kiểm tra dịch vụ & Cấp phát IP hợp lệ (Baseline)

### Bước 1: Kiểm tra dịch vụ DHCP Server hợp lệ
Trên cửa sổ terminal **`dhcpserver`**:
```bash
systemctl status dhcp-server-init.service --no-pager
pgrep -a dhcpd
cat /etc/dhcp/dhcpd.conf
```

### Bước 2: Kiểm tra Scapy Sensor, Web Dashboard & Bắt gói tin Baseline trên `dhcprelay`
Trên cửa sổ terminal **`dhcprelay`**:
```bash
# 1. Kiểm tra tiến trình DHCP Relay, Scapy Sensor và Web Dashboard đã tự khởi chạy
pgrep -af "dhcrelay|dhcp_sniffer.py|dashboard/app.py"

# 2. Xem cấu hình Allowlist máy chủ DHCP hợp lệ
cat /etc/dhcp-rogue-monitor/trusted_servers.yaml

# 3. Bắt gói tin DHCP & ARP giai đoạn Baseline lưu vào normal.pcapng (chạy ngầm)
EXT_IF=$(ip -o -4 addr show | awk '$4 ~ /^10\.10\.0\./ {print $2; exit}')
sudo dumpcap -i "$EXT_IF" -f "(udp port 67 or udp port 68) or arp" -w /home/ubuntu/captures/normal.pcapng &
```
> **Điều kiện đạt checkwork (`sensor_active`):** Tiến trình `dhcp_sniffer.py` và `dashboard/app.py` đang hoạt động và ghi nhận trạng thái vào `/var/log/dhcp_rogue_detection.log`.

### Bước 3: Máy Client xin cấp phát IP động hợp lệ
Trên cửa sổ terminal **`client`**:
```bash
# 1. Kiểm tra trạng thái card mạng ban đầu
ip addr show eth0

# 2. Xin cấp phát IP động từ DHCP Server qua Relay
sudo dhclient -v eth0

# 3. Kiểm tra địa chỉ IP (10.10.0.100) và Default Gateway (10.10.0.1) nhận được
ip addr show eth0
ip route show
```
> **Điều kiện đạt checkwork (`client_baseline_ip`):** File `/var/lib/dhcp/dhclient.leases` trên `client` ghi nhận địa chỉ IP động hợp lệ trong dải `10.10.0.0/24`.

### Bước 4: Dừng bắt gói Baseline & Quan sát kết quả Fingerprinting trên `dhcprelay`
Quay lại cửa sổ terminal **`dhcprelay`**:
```bash
# 1. Dừng tiến trình dumpcap đang chạy ngầm
sudo pkill -INT dumpcap

# 2. Kiểm tra các gói tin vừa bắt được trong normal.pcapng bằng tshark
tshark -r /home/ubuntu/captures/normal.pcapng

# 3. Xem hồ sơ máy chủ hợp lệ và bảng cảnh báo từ Scapy Sensor
cat /var/log/dhcp-rogue-monitor/servers.json
tail -n 10 /var/log/dhcp_rogue_detection.log
```
> **Hiện tượng quan sát:** Sensor nhận diện máy chủ `192.168.0.100` (qua MAC Relay `02:42:0a:0a:00:01`) là **`TRUSTED`** với chuỗi Option Fingerprint `53,54,51,1,3,15,6` và mức thông báo `INFO` (không có cảnh báo giả).

---

## 3. GIAI ĐOẠN 2: Tấn công Rogue DHCP Server & Phát hiện bằng Scapy Fingerprinting

### Bước 5: Mở phiên bắt gói tin giai đoạn tấn công trên `dhcprelay`
Trên cửa sổ terminal **`dhcprelay`**:
```bash
EXT_IF=$(ip -o -4 addr show | awk '$4 ~ /^10\.10\.0\./ {print $2; exit}')
sudo dumpcap -i "$EXT_IF" -f "(udp port 67 or udp port 68) or arp" -w /home/ubuntu/captures/rogue_attack.pcapng &
```

### Bước 6: Khởi chạy Rogue DHCP Server bằng Scapy trên `attacker`
Trên cửa sổ terminal **`attacker`**:
```bash
# 1. Gán địa chỉ IP 10.10.0.20/24 cho card mạng eth0 của Attacker
sudo ip addr add 10.10.0.20/24 dev eth0 2>/dev/null || true
sudo ip link set eth0 up

# 2. Chạy công cụ Rogue DHCP Server (lắng nghe DHCPDISCOVER và phản hồi DHCPOFFER/ACK giả mạo)
sudo python3 /usr/local/bin/rogue_dhcp.py --iface eth0
```
> *(Giữ nguyên tiến trình `rogue_dhcp.py` đang chạy trên cửa sổ `attacker`, đợi dòng `ROGUE_SERVER_STARTED` xuất hiện rồi chuyển sang cửa sổ `client`)*.

### Bước 7: Máy Client giải phóng và xin cấp lại IP trong lúc có Rogue DHCP Server
Chuyển sang cửa sổ terminal **`client`**:
```bash
# 1. Giải phóng địa chỉ IP hiện tại
sudo dhclient -r eth0

# 2. Xin cấp phát lại IP
sudo dhclient -v eth0

# 3. Kiểm tra IP và Gateway hiện tại
ip addr show eth0
ip route show
```
> **Điều kiện đạt checkwork (`rogue_attack_run`):** Tiến trình `rogue_dhcp.py` trên `attacker` đã bắt được `DHCPDISCOVER` từ `client` và phát gói `DHCPOFFER` / `DHCPACK` giả mạo (`Server ID = 10.10.0.20`, `yiaddr = 10.10.0.200`, `Gateway = 10.10.0.20`, `DNS = 10.10.0.20`).

### Bước 8: Dừng bắt gói giai đoạn tấn công & Kiểm tra Cảnh báo Phát hiện trên `dhcprelay`
Chuyển sang cửa sổ terminal **`dhcprelay`**:
```bash
# 1. Dừng tiến trình dumpcap để lưu file rogue_attack.pcapng
sudo pkill -INT dumpcap

# 2. Xem các gói tin cạnh tranh trong rogue_attack.pcapng
tshark -r /home/ubuntu/captures/rogue_attack.pcapng

# 3. Kiểm tra các cảnh báo HIGH / CRITICAL do Detection Engine phát hiện
grep -E "SEVERITY=(HIGH|CRITICAL)" /var/log/dhcp_rogue_detection.log
cat /var/log/dhcp-rogue-monitor/servers.json
```
> **Điều kiện đạt checkwork (`rogue_detected`):**
> - Detection Engine phát hiện máy chủ trái phép `10.10.0.20` (`MAC 02:42:0a:0a:00:14`, Option Fingerprint `53,54,51,1,3,6,15`).
> - Phát hiện nhiều gói `DHCPOFFER` cạnh tranh cùng một Transaction ID (`XID`) và quảng bá Gateway/DNS trái phép (`10.10.0.20`), ghi nhận cảnh báo `SEVERITY=HIGH` / `SEVERITY=CRITICAL`.

---

## 4. GIAI ĐOẠN 3: Giám sát ARP & Quan sát Web Dashboard

### Bước 9: Kiểm tra Bảng ARP và Truy vấn Web Dashboard trên `dhcprelay`
Trên cửa sổ terminal **`dhcprelay`**:
```bash
# 1. Xem bảng giám sát ARP (IP - MAC bindings) do Scapy ARP Monitor thu thập
cat /var/log/dhcp-rogue-monitor/arp_table.json

# 2. Truy vấn API tổng hợp của Web Dashboard tại cổng 5000 bằng wget
wget -qO- http://127.0.0.1:5000/api/summary | python3 -m json.tool | head -n 45
```
> Bạn cũng có thể mở trình duyệt hoặc Wireshark trực tiếp trên `dhcprelay` (`wireshark /home/ubuntu/captures/rogue_attack.pcapng &`).

---

## 5. GIAI ĐOẠN 4: Dừng Rogue DHCP Server & Khôi phục Cấu hình Hợp lệ (Recovery)

### Bước 10: Dừng Rogue DHCP Server trên `attacker`
Quay lại cửa sổ terminal **`attacker`** đang chạy `rogue_dhcp.py`, nhấn tổ hợp phím **`Ctrl + C`** để dừng tiến trình Rogue DHCP Server (hoặc gõ `sudo pkill -INT -f rogue_dhcp.py`).

### Bước 11: Bắt gói tin giai đoạn Phục hồi & Cấp phát lại IP hợp lệ cho `client`
1. Trên cửa sổ terminal **`dhcprelay`**, bắt đầu ghi file `recovery.pcapng`:
   ```bash
   EXT_IF=$(ip -o -4 addr show | awk '$4 ~ /^10\.10\.0\./ {print $2; exit}')
   sudo dumpcap -i "$EXT_IF" -f "(udp port 67 or udp port 68) or arp" -w /home/ubuntu/captures/recovery.pcapng &
   ```
2. Trên cửa sổ terminal **`client`**, giải phóng cấu hình cũ và xin lại IP hợp lệ:
   ```bash
   sudo dhclient -r eth0
   sudo dhclient -v eth0
   ip addr show eth0
   ip route show
   ```
3. Quay lại cửa sổ terminal **`dhcprelay`**, dừng bắt gói và kiểm tra cả 3 file PCAPNG:
   ```bash
   sudo pkill -INT dumpcap
   ls -lh /home/ubuntu/captures/*.pcapng
   ```
> **Điều kiện đạt checkwork (`pcap_captured` & `client_recovered`):**
> - Đã thu thập đủ 3 file PCAPNG hợp lệ: `normal.pcapng`, `rogue_attack.pcapng`, `recovery.pcapng`.
> - Máy `client` đã giải phóng (`dhclient -r`) và nhận lại địa chỉ IP hợp lệ (`10.10.0.100`), Default Gateway `10.10.0.1` từ `192.168.0.100`.

---

## 6. GIAI ĐOẠN 5: Xuất Báo cáo Phân tích & Chấm điểm (`checkwork`)

### Bước 12: Xuất báo cáo tổng hợp trên `dhcprelay`
Trên cửa sổ terminal **`dhcprelay`**:
```bash
python3 /usr/local/bin/generate-report.py
```
> **Điều kiện đạt checkwork (`report_generated`):** Báo cáo tổng hợp số lượng DHCP servers, Offer/ACK, Alerts, bảng ARP và thông số 3 file PCAPNG được lưu vào `/home/ubuntu/reports/rogue_detection_report.txt` và `/var/log/dhcp_rogue_report.txt`.

### Bước 13: Chấm điểm tự động trên máy Host (`checkwork`)
Tại terminal máy **Host** (`student@LabtainerVMware`), gõ:
```bash
checkwork dhcp-rogue-monitor
```

| Mục tiêu chấm điểm | Trạng thái | Ý nghĩa |
| :--- | :---: | :--- |
| **`client_baseline_ip`** | **Y** | Client đã xin cấp phát IP động hợp lệ ban đầu bằng `dhclient` |
| **`sensor_active`** | **Y** | Scapy DHCP/ARP Sensor và Web Dashboard hoạt động trên `dhcprelay` |
| **`rogue_attack_run`** | **Y** | Attacker đã chạy `rogue_dhcp.py` và phát tán gói `DHCPOFFER` giả mạo |
| **`rogue_detected`** | **Y** | Detection Engine phát hiện Rogue DHCP Server (`HIGH`/`CRITICAL`) |
| **`pcap_captured`** | **Y** | Đã bắt đủ 3 file PCAPNG (`normal.pcapng`, `rogue_attack.pcapng`, `recovery.pcapng`) |
| **`client_recovered`** | **Y** | Đã dừng Rogue Server và Client khôi phục lại cấu hình IP hợp lệ (`dhclient -r && dhclient`) |
| **`report_generated`** | **Y** | Đã tạo báo cáo phân tích tổng hợp bằng `generate-report.py` |
