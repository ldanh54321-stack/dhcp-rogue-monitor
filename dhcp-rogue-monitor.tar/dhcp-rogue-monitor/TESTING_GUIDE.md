# HƯỚNG DẪN THỰC HÀNH TRỰC TIẾP TRÊN TERMINAL (`TESTING_GUIDE.md`) — `dhcp-rogue-monitor`

Tài liệu này hướng dẫn từng lệnh gõ trực tiếp trên 4 cửa sổ terminal của bài lab **`dhcp-rogue-monitor`** (không phụ thuộc vào các shell script bọc ngoài) để hoàn thành toàn bộ 5 giai đoạn và đạt **7/7 mục tiêu (`Y`)** khi chạy `checkwork`.

---

## Bước 0: Khởi động bài Lab trên máy Host

Tại terminal máy ảo Ubuntu (`student@LabtainerVMware`):
```bash
cd /home/student/labtainer/trunk/scripts/labtainer-student
labtainer -r dhcp-rogue-monitor
```
4 cửa sổ terminal tương tác sẽ bật lên: **`dhcpserver`**, **`dhcprelay`**, **`attacker`**, **`client`**.

---

## GIAI ĐOẠN 1: Kiểm tra Baseline & Bắt gói `normal.pcapng`

### 1.1. Trên cửa sổ terminal `dhcpserver`
Kiểm tra dịch vụ ISC DHCP Server và cấu hình cấp phát:
```bash
pgrep -a dhcpd
cat /etc/dhcp/dhcpd.conf
```

### 1.2. Trên cửa sổ terminal `dhcprelay`
Kiểm tra tiến trình Relay/Sensor/Dashboard, xem file cấu hình Allowlist và bật `dumpcap` bắt gói tin vào `/home/ubuntu/captures/normal.pcapng`:
```bash
pgrep -af "dhcrelay|dhcp_sniffer.py|dashboard/app.py"
cat /etc/dhcp-rogue-monitor/trusted_servers.yaml
EXT_IF=$(ip -o -4 addr show | awk '$4 ~ /^10\.10\.0\./ {print $2; exit}')
sudo dumpcap -i "$EXT_IF" -f "(udp port 67 or udp port 68) or arp" -w /home/ubuntu/captures/normal.pcapng &
```

### 1.3. Trên cửa sổ terminal `client`
Xin cấp phát địa chỉ IP động bằng `dhclient`:
```bash
ip addr show eth0
sudo dhclient -v eth0
ip addr show eth0
ip route show
```
*(Client nhận IP `10.10.0.100`, Default Gateway `10.10.0.1` từ Server ID `192.168.0.100`)*.

### 1.4. Trên cửa sổ terminal `dhcprelay`
Dừng bắt gói `normal.pcapng` và kiểm tra kết quả:
```bash
sudo pkill -INT dumpcap
tshark -r /home/ubuntu/captures/normal.pcapng
cat /var/log/dhcp-rogue-monitor/servers.json
```

---

## GIAI ĐOẠN 2: Tấn công Rogue DHCP Server & Bắt gói `rogue_attack.pcapng`

### 2.1. Trên cửa sổ terminal `dhcprelay`
Bật `dumpcap` bắt gói tin giai đoạn tấn công vào `/home/ubuntu/captures/rogue_attack.pcapng`:
```bash
EXT_IF=$(ip -o -4 addr show | awk '$4 ~ /^10\.10\.0\./ {print $2; exit}')
sudo dumpcap -i "$EXT_IF" -f "(udp port 67 or udp port 68) or arp" -w /home/ubuntu/captures/rogue_attack.pcapng &
```

### 2.2. Trên cửa sổ terminal `attacker`
Gán IP `10.10.0.20/24` lên card `eth0` và khởi chạy trực tiếp công cụ Scapy Rogue DHCP Server:
```bash
sudo ip addr add 10.10.0.20/24 dev eth0 2>/dev/null || true
sudo ip link set eth0 up
sudo python3 /usr/local/bin/rogue_dhcp.py --iface eth0
```
*(Đợi dòng `ROGUE_SERVER_STARTED` in ra trên màn hình `attacker`, giữ nguyên tiến trình đang chạy)*.

### 2.3. Trên cửa sổ terminal `client`
Giải phóng IP hiện tại và xin cấp phát lại IP trong lúc Rogue DHCP Server đang hoạt động:
```bash
sudo dhclient -r eth0
sudo dhclient -v eth0
ip addr show eth0
ip route show
```

### 2.4. Trên cửa sổ terminal `dhcprelay`
Dừng `dumpcap` và kiểm tra các cảnh báo `HIGH` / `CRITICAL` phát hiện Rogue Server `10.10.0.20`:
```bash
sudo pkill -INT dumpcap
tshark -r /home/ubuntu/captures/rogue_attack.pcapng
grep -E "SEVERITY=(HIGH|CRITICAL)" /var/log/dhcp_rogue_detection.log
cat /var/log/dhcp-rogue-monitor/servers.json
```

---

## GIAI ĐOẠN 3: Giám sát ARP & Kiểm tra Web Dashboard

Trên cửa sổ terminal **`dhcprelay`**:
```bash
# Xem bảng ánh xạ IP - MAC thu thập bởi Scapy ARP Monitor
cat /var/log/dhcp-rogue-monitor/arp_table.json

# Truy vấn dữ liệu JSON trực tiếp từ Web Dashboard (cổng 5000) bằng wget
wget -qO- http://127.0.0.1:5000/api/summary | python3 -m json.tool | head -n 45
```

---

## GIAI ĐOẠN 4: Dừng Rogue DHCP Server & Khôi phục (`recovery.pcapng`)

### 4.1. Trên cửa sổ terminal `attacker`
Nhấn tổ hợp phím **`Ctrl + C`** để dừng tiến trình `rogue_dhcp.py`.

### 4.2. Trên cửa sổ terminal `dhcprelay`
Bật `dumpcap` bắt gói tin giai đoạn phục hồi vào `/home/ubuntu/captures/recovery.pcapng`:
```bash
EXT_IF=$(ip -o -4 addr show | awk '$4 ~ /^10\.10\.0\./ {print $2; exit}')
sudo dumpcap -i "$EXT_IF" -f "(udp port 67 or udp port 68) or arp" -w /home/ubuntu/captures/recovery.pcapng &
```

### 4.3. Trên cửa sổ terminal `client`
Giải phóng lease cũ và xin cấp lại cấu hình IP hợp lệ từ DHCP Server:
```bash
sudo dhclient -r eth0
sudo dhclient -v eth0
ip addr show eth0
ip route show
```

### 4.4. Trên cửa sổ terminal `dhcprelay`
Dừng `dumpcap` và kiểm tra đủ 3 file PCAPNG:
```bash
sudo pkill -INT dumpcap
ls -lh /home/ubuntu/captures/*.pcapng
```

---

## GIAI ĐOẠN 5: Xuất Báo cáo Phân tích & Chấm điểm (`checkwork`)

### 5.1. Trên cửa sổ terminal `dhcprelay`
Chạy công cụ Python tổng hợp báo cáo từ 3 file PCAPNG và dữ liệu Sensor:
```bash
python3 /usr/local/bin/generate-report.py
```

### 5.2. Trên terminal máy Host (`student@LabtainerVMware`)
Chạy lệnh chấm điểm tự động:
```bash
cd /home/student/labtainer/trunk/scripts/labtainer-student
checkwork dhcp-rogue-monitor
```
Kết quả đạt đủ **7/7 mục tiêu (`Y`)**. Khi hoàn tất, dừng bài lab bằng:
```bash
stoplab dhcp-rogue-monitor
```
