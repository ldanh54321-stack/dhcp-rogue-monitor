# BÁO CÁO KIỂM THỬ TRƯỚC VÀ SAU PHÁT HÀNH (`RELEASE_TEST_REPORT.md`)

- **Tên bài Labtainer:** `dhcp-rogue-monitor`
- **Tên dự án:** DHCP Rogue Server Detection Using DHCP Fingerprinting & ARP Monitoring
- **Phiên bản:** `v1.0.0`
- **Ngày kiểm thử:** `2026-11-10`

---

## 1. Thông Tin Môi Trường Đã Kiểm Thử

| Hạng mục | Thông số thực tế |
| :--- | :--- |
| **Hệ điều hành** | Ubuntu 24.04 LTS (`x86_64`) |
| **Phiên bản Docker** | `Docker version 27.0.3, build 7d4bcd8` |
| **Phiên bản Labtainers** | `v1.4.4n` (`LABTAINER_DIR=/home/student/labtainer/trunk`) |
| **Kiến trúc mạng bài Lab** | Dual-Subnet (`INTERNAL_NET: 192.168.0.0/24` & `EXTERNAL_NET: 10.10.0.0/24`) |
| **Docker Hub Namespace** | `zeus183` ([https://hub.docker.com/r/zeus183/dhcp-rogue-monitor](https://hub.docker.com/r/zeus183/dhcp-rogue-monitor)) |
| **GitHub Repository** | `ldanh54321-stack/dhcp-rogue-monitor` ([https://github.com/ldanh54321-stack/dhcp-rogue-monitor](https://github.com/ldanh54321-stack/dhcp-rogue-monitor)) |

---

## 2. Bảng Tổng Hợp Kết Quả Các Hạng Mục Kiểm Thử Bắt Buộc

| Mã Test | Hạng mục kiểm thử | Trạng thái | Bằng chứng & Kết quả thực nghiệm chi tiết |
| :--- | :--- | :---: | :--- |
| **T01** | **Build 4 Docker Images (`build-images.sh`)** | **PASS** | Đã build thành công 4 image độc lập (`dhcpserver`, `dhcprelay`, `attacker`, `client`) dưới namespace `zeus183` (kèm tag `:latest`, `:v1.0.0` và repo tổng hợp `zeus183/dhcp-rogue-monitor:<role>`). Không làm thay đổi image gốc của các bài lab khác. |
| **T02** | **Đóng gói & Kiểm tra TAR (`package-lab.sh` & `validate-package.sh`)** | **PASS** | File `dhcp-rogue-monitor.tar` có thư mục gốc `dhcp-rogue-monitor/` đúng chuẩn `imodule`, đủ 100% file cấu hình/mã nguồn, 0 file rác/log/pcap, 0 token bị lộ, khớp hoàn toàn SHA256. |
| **T03** | **Kiểm thử Import bằng `imodule` trên môi trường sạch (`test-import.sh`)** | **PASS** | Đã tạm cất thư mục bài lab, chạy `/home/student/labtainer/trunk/scripts/labtainer-student/bin/imodule` với gói `dhcp-rogue-monitor.tar`, giải nén chuẩn vào `$LABTAINER_DIR/labs/dhcp-rogue-monitor` và hiển thị trong `labtainer -l`. |
| **T04** | **Khởi động bài lab (`labtainer dhcp-rogue-monitor`)** | **PASS** | Tự động tạo 2 mạng Docker (`INTERNAL_NET`, `EXTERNAL_NET`) và khởi chạy 4 container (`dhcpserver`, `dhcprelay`, `attacker`, `client`) kèm 4 cửa sổ terminal tương tác. |
| **T05** | **Chức năng DHCP Server hợp lệ & Client Baseline** | **PASS** | `dhcpd` trên `192.168.0.100` cấp phát IP `10.10.0.100/24`, Gateway `10.10.0.1`, DNS `192.168.0.100` cho `client` thông qua `dhcprelay`. |
| **T06** | **Chức năng Kali Rogue DHCP Server (`rogue_dhcp.py`)** | **PASS** | Khởi chạy theo yêu cầu trên `attacker` (`10.10.0.20`, MAC `02:42:0a:0a:00:14`), phát `DHCPOFFER` / `DHCPACK` giả mạo (`yiaddr=10.10.0.200`, `GW=10.10.0.20`, `DNS=10.10.0.20`), hỗ trợ dừng ngay bằng `Ctrl+C`. Cô lập 100% trong `EXTERNAL_NET`. |
| **T07** | **Scapy DHCP Option Fingerprinting (`dhcp_fingerprint.py`, `detection_engine.py`)** | **PASS** | Trích xuất chính xác `Option 54 (Server ID)`, `Option 3 (Router)`, `Option 6 (DNS)`, `Option 51 (Lease)`, `XID`, `giaddr` và chuỗi `Option Fingerprint` (`53,54,51,1,3,15,6` của Server hợp lệ vs `53,54,51,1,3,6,15` của Rogue Server). Phát hiện `HIGH` (`ROGUE_DHCP_OFFER_DETECTED`, `COMPETING_DHCP_OFFERS_SAME_XID`) và `CRITICAL` (`ROGUE_DHCP_ACK_CLIENT_COMPROMISED`). |
| **T08** | **Giám sát và Tương quan ARP (`arp_monitor.py`)** | **PASS** | Ghi nhận chính xác bảng ánh xạ IP-MAC thực tế (`10.10.0.1 -> 02:42:0a:0a:00:01`, `10.10.0.20 -> 02:42:0a:0a:00:14`, `10.10.0.100/200 -> 02:42:0a:0a:00:32`), không sinh cảnh báo giả. |
| **T09** | **Web Dashboard (`http://10.10.0.1:5000`)** | **PASS** | Tự động khởi chạy qua `dhcp-rogue-monitor.service`, hiển thị dữ liệu thật 100% qua giao diện HTML/CSS/JS và JSON API (`/api/summary`, `/api/servers`, `/api/alerts`, `/api/arp`). |
| **T10** | **Wireshark / TShark & Bộ 3 file PCAPNG** | **PASS** | Bắt và lưu thành công `normal.pcapng`, `rogue_attack.pcapng`, `recovery.pcapng` trong `/home/ubuntu/captures/`, đọc và phân tích hợp lệ bằng `tshark` / `wireshark`. |
| **T11** | **Khôi phục Client, Dừng & Chạy lại bài Lab + Chấm điểm `checkwork`** | **PASS** | Sau khi dừng Rogue Server, `client` xin lại được IP hợp lệ `10.10.0.100`. `checkwork dhcp-rogue-monitor` đạt tuyệt đối **7/7 mục tiêu (`Y`)**. `stoplab dhcp-rogue-monitor` dọn dẹp sạch container và network tạm. |
| **T12** | **Push & Pull Docker Images từ Docker Hub (`zeus183`)** | **PASS** | Đã push thành công 18 tags lên `zeus183/dhcp-rogue-monitor*` và xác minh `docker pull` thành công cho cả 4 role (`dhcpserver`, `dhcprelay`, `attacker`, `client`) và `zeus183/dhcp-rogue-monitor:v1.0.0`. |
| **T13** | **Import trực tiếp bằng `imodule` từ URL GitHub Release `v1.0.0`** | **PASS** | Đã chạy `imodule https://github.com/ldanh54321-stack/dhcp-rogue-monitor/releases/download/v1.0.0/dhcp-rogue-monitor.tar` trên môi trường sạch (SHA256: `3426383adb14aa0f1e54716c10e3f33e14229c495f5334f2f8f9f1ba11165a1b`), giải nén tự động và hiển thị trong `labtainer -l`. |

---

## 3. Các Lỗi Đã Phát Hiện & Khắc Phục Triệt Để Trước Khi Phát Hành

1. **Bộ lọc đóng gói `*token*` trong `package-lab.sh` xóa nhầm file `yaml/tokens.py` của thư viện `PyYAML`:**
   - *Nguyên nhân:* Biểu thức `find ... -name "*token*" -delete` vô tình xóa mất module chuẩn `/usr/lib/python3/dist-packages/yaml/tokens.py` được đóng gói trong `dhcprelay/_system`.
   - *Khắc phục:* Đã loại bỏ `-name "*token*"` khỏi lệnh xóa mù và thay bằng bộ quét regex nội dung token thực tế (`ghp_...`, `github_pat_...`, `dckr_pat_...`), đồng thời khôi phục đầy đủ `yaml/tokens.py` vào image.
2. **Tín hiệu `Ctrl + C` (`SIGINT`) khi dừng `rogue_dhcp.py` bị trễ nếu không có gói DHCP mới:**
   - *Nguyên nhân:* Hàm `sniff()` của Scapy chỉ kiểm tra `stop_filter` sau khi nhận một gói tin mới.
   - *Khắc phục:* Cập nhật `handle_sig()` trong `rogue_dhcp.py` ghi log `ROGUE_SERVER_STOPPED` và gọi `os._exit(0)` để trả lại dấu nhắc terminal tức thì khi người dùng nhấn `Ctrl + C`.
3. **Thiếu lệnh `curl` trong base image `dhcprelay`:**
   - *Nguyên nhân:* Base image `labtainer.network.ssh2` cài sẵn `wget` và `python3` nhưng không cài `curl`.
   - *Khắc phục:* Cập nhật toàn bộ tài liệu hướng dẫn sang sử dụng `wget -qO- http://127.0.0.1:5000/api/summary | python3 -m json.tool`.

