function esc(val) {
  if (val === null || val === undefined) return "";
  return String(val)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function drawTimelineChart(timeline) {
  const canvas = document.getElementById("timeline-chart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const W = canvas.width;
  const H = canvas.height;
  ctx.clearRect(0, 0, W, H);

  ctx.strokeStyle = "#334155";
  ctx.lineWidth = 1;
  for (let i = 1; i <= 3; i++) {
    const y = (H / 4) * i;
    ctx.beginPath();
    ctx.moveTo(40, y);
    ctx.lineTo(W - 15, y);
    ctx.stroke();
  }

  if (!timeline || timeline.length === 0) {
    ctx.fillStyle = "#64748b";
    ctx.font = "13px sans-serif";
    ctx.fillText("Đang chờ dữ liệu gói tin DHCP theo thời gian...", W / 2 - 140, H / 2);
    return;
  }

  const maxVal = Math.max(
    5,
    ...timeline.map(b => Math.max(b.dhcp_packets || 0, b.alerts || 0))
  );

  const plotW = W - 65;
  const plotH = H - 35;
  const stepX = plotW / Math.max(1, timeline.length - 1);

  // Draw DHCP packets line (cyan)
  ctx.strokeStyle = "#38bdf8";
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  timeline.forEach((pt, idx) => {
    const x = 45 + idx * stepX;
    const y = 12 + plotH - ((pt.dhcp_packets || 0) / maxVal) * plotH;
    if (idx === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();

  // Draw Alerts line (red/orange)
  ctx.strokeStyle = "#ef4444";
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  timeline.forEach((pt, idx) => {
    const x = 45 + idx * stepX;
    const y = 12 + plotH - ((pt.alerts || 0) / maxVal) * plotH;
    if (idx === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();

  // Legend
  ctx.fillStyle = "#38bdf8";
  ctx.fillRect(50, 4, 12, 4);
  ctx.fillStyle = "#cbd5e1";
  ctx.font = "11px sans-serif";
  ctx.fillText("DHCP Packets", 66, 10);

  ctx.fillStyle = "#ef4444";
  ctx.fillRect(160, 4, 12, 4);
  ctx.fillStyle = "#cbd5e1";
  ctx.fillText("Alerts (WARN/HIGH/CRIT)", 176, 10);
}

async function refreshDashboard() {
  try {
    const resp = await fetch("/api/summary", { cache: "no-store" });
    if (!resp.ok) return;
    const data = await resp.json();
    const st = data.stats || {};
    const sev = st.alerts_by_severity || { INFO: 0, WARNING: 0, HIGH: 0, CRITICAL: 0 };

    document.getElementById("last-updated").textContent =
      "Cập nhật: " + (st.last_updated || data.timestamp || "--");

    const badge = document.getElementById("sensor-badge");
    badge.textContent = "SENSOR: " + (st.sensor_status || "ACTIVE");

    document.getElementById("kpi-total-dhcp").textContent = st.total_dhcp_packets || 0;
    document.getElementById("kpi-dhcp-breakdown").textContent =
      `D:${st.discover_count || 0} | O:${st.offer_count || 0} | R:${st.request_count || 0} | A:${st.ack_count || 0}`;

    document.getElementById("kpi-trusted-servers").textContent = st.trusted_servers_seen || 0;
    document.getElementById("kpi-rogue-servers").textContent = st.rogue_servers_seen || 0;

    const highCrit = (sev.HIGH || 0) + (sev.CRITICAL || 0);
    document.getElementById("kpi-high-crit").textContent = highCrit;
    document.getElementById("kpi-alert-breakdown").textContent =
      `CRIT:${sev.CRITICAL || 0} | HIGH:${sev.HIGH || 0} | WARN:${sev.WARNING || 0} | INFO:${sev.INFO || 0}`;

    document.getElementById("kpi-arp-packets").textContent = st.arp_packets || 0;

    drawTimelineChart(st.timeline || []);

    // Render servers
    const serversTbody = document.getElementById("servers-tbody");
    const servers = data.servers || [];
    if (servers.length === 0) {
      serversTbody.innerHTML = '<tr><td colspan="9" class="empty">Chưa ghi nhận gói tin DHCPOFFER/DHCPACK nào...</td></tr>';
    } else {
      serversTbody.innerHTML = servers.map(s => {
        const isTrusted = s.status === "TRUSTED";
        const badgeCls = isTrusted ? "badge-trusted" : "badge-rogue";
        return `<tr>
          <td><span class="badge ${badgeCls}">${esc(s.status)}</span></td>
          <td><code>${esc(s.server_id)}</code></td>
          <td><code>${esc(s.observed_mac)}</code></td>
          <td>${esc(s.relay_context)}</td>
          <td><code>${esc(s.router_offered)}</code></td>
          <td><code>${esc(s.dns_offered)}</code></td>
          <td>${esc(s.lease_time)}s</td>
          <td><code>${esc(s.fingerprint_signature)}</code></td>
          <td><b>${esc(s.offer_count)}</b> / <b>${esc(s.ack_count)}</b></td>
        </tr>`;
      }).join("");
    }

    // Render alerts
    const alertsTbody = document.getElementById("alerts-tbody");
    const alerts = data.alerts || [];
    if (alerts.length === 0) {
      alertsTbody.innerHTML = '<tr><td colspan="9" class="empty">Chưa có cảnh báo nào...</td></tr>';
    } else {
      alertsTbody.innerHTML = alerts.slice(0, 25).map(a => {
        return `<tr>
          <td><code>${esc(a.alert_id)}</code></td>
          <td><code>${esc((a.timestamp || "").slice(11, 19))}</code></td>
          <td><span class="badge badge-${esc(a.severity)}">${esc(a.severity)}</span></td>
          <td><b>${esc(a.alert_type)}</b></td>
          <td><code>${esc(a.server_id)}</code></td>
          <td><code>${esc(a.observed_mac)}</code></td>
          <td><code>${esc(a.client_mac)}</code></td>
          <td><code>${esc(a.xid)}</code></td>
          <td>${esc(a.reason)}</td>
        </tr>`;
      }).join("");
    }

    // Render ARP table
    const arpTbody = document.getElementById("arp-tbody");
    const arpList = data.arp_table || [];
    if (arpList.length === 0) {
      arpTbody.innerHTML = '<tr><td colspan="5" class="empty">Chưa có mục ARP nào...</td></tr>';
    } else {
      arpTbody.innerHTML = arpList.map(r => {
        return `<tr>
          <td><code>${esc(r.ip)}</code></td>
          <td><code>${esc(r.mac)}</code></td>
          <td><span class="badge ${r.status.includes("SPOOF") || r.status.includes("CHANGED") ? "badge-HIGH" : "badge-INFO"}">${esc(r.status)}</span></td>
          <td>${esc(r.packet_count)}</td>
          <td><code>${esc((r.history_macs || []).join(", "))}</code></td>
        </tr>`;
      }).join("");
    }

    // Render Events
    const eventsTbody = document.getElementById("events-tbody");
    const events = data.events || [];
    if (events.length === 0) {
      eventsTbody.innerHTML = '<tr><td colspan="6" class="empty">Đang chờ gói tin DHCP...</td></tr>';
    } else {
      eventsTbody.innerHTML = events.slice(0, 15).map(ev => {
        return `<tr>
          <td><b>${esc(ev.message_type)}</b></td>
          <td><code>${esc(ev.xid)}</code></td>
          <td><code>${esc(ev.client_mac)}</code></td>
          <td><code>${esc(ev.server_id || "-")}</code></td>
          <td><code>${esc(ev.yiaddr || "-")}</code></td>
          <td><code>GW:${esc(ev.router || "-")} / DNS:${esc((ev.dns_servers || []).join(",") || "-")}</code></td>
        </tr>`;
      }).join("");
    }
  } catch (err) {
    console.error("Dashboard poll error:", err);
  }
}

setInterval(refreshDashboard, 2000);
refreshDashboard();

