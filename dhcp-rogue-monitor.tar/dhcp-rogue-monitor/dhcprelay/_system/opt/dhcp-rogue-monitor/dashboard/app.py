#!/usr/bin/env python3
"""
app.py - Lightweight Real-Time Web Dashboard for DHCP Rogue Server Detection
Serves the dashboard HTML/CSS/JS and live JSON APIs reading directly from
/var/log/dhcp-rogue-monitor/*.json without requiring external internet or CDNs.
Supports Flask if installed, with automatic fallback to Python's ThreadingHTTPServer.
"""

import argparse
import json
import os
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")
STATIC_DIR = os.path.join(BASE_DIR, "static")
LOG_DIR = "/var/log/dhcp-rogue-monitor"
DETECTION_LOG = "/var/log/dhcp_rogue_detection.log"


def read_json_safe(filename, default):
    path = os.path.join(LOG_DIR, filename)
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def build_summary_payload():
    stats = read_json_safe("stats.json", {})
    servers = read_json_safe("servers.json", [])
    alerts = read_json_safe("alerts.json", [])
    events = read_json_safe("events.json", [])
    arp_table = read_json_safe("arp_table.json", [])

    if not isinstance(stats, dict):
        stats = {}
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "stats": stats,
        "servers": servers if isinstance(servers, list) else [],
        "alerts": list(reversed(alerts[-100:])) if isinstance(alerts, list) else [],
        "events": list(reversed(events[-50:])) if isinstance(events, list) else [],
        "arp_table": arp_table if isinstance(arp_table, list) else [],
    }


def mark_dashboard_active(host, port):
    os.makedirs(LOG_DIR, exist_ok=True)
    ts = datetime.now(timezone.utc).isoformat()
    try:
        with open(DETECTION_LOG, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] DASHBOARD_ACTIVE host={host} port={port}\n")
        os.chmod(DETECTION_LOG, 0o666)
    except OSError:
        pass


class DashboardRequestHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # Quiet standard stdout logging
        pass

    def _send_json(self, data, status=200):
        raw = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _send_file(self, filepath, content_type):
        if not os.path.isfile(filepath):
            self.send_error(404, "File not found")
            return
        with open(filepath, "rb") as f:
            raw = f.read()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        parsed = urlparse(self.path)
        route = parsed.path

        if route in ("/", "/index.html"):
            self._send_file(os.path.join(TEMPLATE_DIR, "index.html"), "text/html; charset=utf-8")
        elif route == "/static/style.css":
            self._send_file(os.path.join(STATIC_DIR, "style.css"), "text/css; charset=utf-8")
        elif route == "/static/dashboard.js":
            self._send_file(os.path.join(STATIC_DIR, "dashboard.js"), "application/javascript; charset=utf-8")
        elif route == "/api/summary":
            self._send_json(build_summary_payload())
        elif route == "/api/alerts":
            self._send_json(read_json_safe("alerts.json", []))
        elif route == "/api/servers":
            self._send_json(read_json_safe("servers.json", []))
        elif route == "/api/arp":
            self._send_json(read_json_safe("arp_table.json", []))
        elif route == "/api/events":
            self._send_json(read_json_safe("events.json", []))
        elif route == "/health":
            self._send_json({"status": "ok", "service": "dhcp-rogue-monitor-dashboard"})
        else:
            self.send_error(404, "Not Found")


def main():
    parser = argparse.ArgumentParser(description="DHCP Rogue Monitor Web Dashboard")
    parser.add_argument("--host", default="0.0.0.0", help="Bind address (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=5000, help="Bind port (default: 5000)")
    args = parser.parse_args()

    mark_dashboard_active(args.host, args.port)
    server = ThreadingHTTPServer((args.host, args.port), DashboardRequestHandler)
    print(f"[*] DHCP Rogue Monitor Dashboard listening on http://{args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()

