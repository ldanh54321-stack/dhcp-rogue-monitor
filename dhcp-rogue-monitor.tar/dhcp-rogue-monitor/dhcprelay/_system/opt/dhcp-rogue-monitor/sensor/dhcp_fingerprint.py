#!/usr/bin/env python3
"""
dhcp_fingerprint.py - DHCP Option & Packet Fingerprinting Parser (Scapy)
Extracts detailed DHCP headers, BOOTP fields, Option 54 (Server Identifier),
Option 3 (Router), Option 6 (DNS), Option 51 (Lease Time), Option 82 (Relay Agent),
and the ordered DHCP Option Fingerprint sequence.
"""

from datetime import datetime, timezone
from scapy.all import Ether, IP, UDP, BOOTP, DHCP

DHCP_MESSAGE_TYPES = {
    1: "DISCOVER",
    2: "OFFER",
    3: "REQUEST",
    4: "DECLINE",
    5: "ACK",
    6: "NAK",
    7: "RELEASE",
    8: "INFORM",
}

OPTION_NAME_TO_CODE = {
    "pad": 0,
    "subnet_mask": 1,
    "time_zone": 2,
    "router": 3,
    "time_server": 4,
    "IEN_name_server": 5,
    "name_server": 6,
    "log_server": 7,
    "cookie_server": 8,
    "lpr_server": 9,
    "hostname": 12,
    "domain": 15,
    "broadcast_address": 28,
    "requested_addr": 50,
    "lease_time": 51,
    "dhcp-message-type": 53,
    "message-type": 53,
    "server_id": 54,
    "param_req_list": 55,
    "error_message": 56,
    "max_dhcp_size": 57,
    "renewal_time": 58,
    "rebinding_time": 59,
    "vendor_class_id": 60,
    "client_id": 61,
    "relay_agent_Information": 82,
    "end": 255,
}


def format_mac(raw_chaddr):
    """Convert 16-byte BOOTP chaddr or raw bytes into standard colon-separated MAC."""
    if not raw_chaddr:
        return "00:00:00:00:00:00"
    if isinstance(raw_chaddr, bytes):
        mac_bytes = raw_chaddr[:6]
        return ":".join(f"{b:02x}" for b in mac_bytes)
    return str(raw_chaddr).lower()


def decode_val(val):
    if isinstance(val, bytes):
        try:
            return val.decode("utf-8", errors="ignore").rstrip("\x00")
        except Exception:
            return val.hex()
    if isinstance(val, (list, tuple)):
        return [decode_val(x) for x in val]
    return val


def extract_dhcp_fingerprint(pkt, iface="eth1"):
    """
    Parse a Scapy packet containing BOOTP/DHCP layers and return a structured
    fingerprint dictionary, or None if not a DHCP packet.
    """
    if not (pkt.haslayer(DHCP) and pkt.haslayer(BOOTP)):
        return None

    now_iso = datetime.now(timezone.utc).isoformat()
    eth_src = pkt[Ether].src.lower() if pkt.haslayer(Ether) else "00:00:00:00:00:00"
    eth_dst = pkt[Ether].dst.lower() if pkt.haslayer(Ether) else "ff:ff:ff:ff:ff:ff"
    ip_src = pkt[IP].src if pkt.haslayer(IP) else "0.0.0.0"
    ip_dst = pkt[IP].dst if pkt.haslayer(IP) else "255.255.255.255"
    udp_sport = int(pkt[UDP].sport) if pkt.haslayer(UDP) else 0
    udp_dport = int(pkt[UDP].dport) if pkt.haslayer(UDP) else 0

    bootp = pkt[BOOTP]
    xid = f"0x{int(bootp.xid):08x}"
    ciaddr = str(bootp.ciaddr)
    yiaddr = str(bootp.yiaddr)
    siaddr = str(bootp.siaddr)
    giaddr = str(bootp.giaddr)
    client_mac = format_mac(bootp.chaddr)

    msg_type_code = 0
    msg_type_str = "UNKNOWN"
    server_id = None
    router = None
    dns_servers = []
    lease_time = None
    subnet_mask = None
    domain_name = None
    requested_addr = None
    option_82 = None
    param_req_list = []
    option_sequence = []
    options_dict = {}

    for opt in pkt[DHCP].options:
        if isinstance(opt, str):
            if opt == "end":
                option_sequence.append("255:end")
            elif opt == "pad":
                continue
            else:
                option_sequence.append(opt)
            continue

        if not isinstance(opt, tuple) or len(opt) < 2:
            continue

        opt_key = opt[0]
        opt_val = opt[1] if len(opt) == 2 else list(opt[1:])
        opt_code = OPTION_NAME_TO_CODE.get(opt_key, opt_key)
        option_sequence.append(f"{opt_code}:{opt_key}")

        if opt_key in ("message-type", "dhcp-message-type"):
            if isinstance(opt_val, int):
                msg_type_code = opt_val
                msg_type_str = DHCP_MESSAGE_TYPES.get(opt_val, f"TYPE_{opt_val}")
            else:
                msg_type_str = str(opt_val).upper()
                for k, v in DHCP_MESSAGE_TYPES.items():
                    if v == msg_type_str:
                        msg_type_code = k
                        break
        elif opt_key == "server_id":
            server_id = str(decode_val(opt_val))
        elif opt_key == "router":
            if isinstance(opt_val, (list, tuple)):
                router = str(decode_val(opt_val[0])) if opt_val else None
            else:
                router = str(decode_val(opt_val))
        elif opt_key == "name_server":
            if isinstance(opt_val, (list, tuple)):
                dns_servers = [str(decode_val(x)) for x in opt_val]
            else:
                dns_servers = [str(decode_val(opt_val))]
        elif opt_key == "lease_time":
            try:
                lease_time = int(opt_val)
            except Exception:
                lease_time = decode_val(opt_val)
        elif opt_key == "subnet_mask":
            subnet_mask = str(decode_val(opt_val))
        elif opt_key == "domain":
            domain_name = str(decode_val(opt_val))
        elif opt_key == "requested_addr":
            requested_addr = str(decode_val(opt_val))
        elif opt_key in ("relay_agent_Information", 82):
            option_82 = decode_val(opt_val)
        elif opt_key == "param_req_list":
            if isinstance(opt_val, (bytes, bytearray)):
                param_req_list = [int(b) for b in opt_val]
            elif isinstance(opt_val, (list, tuple)):
                param_req_list = [int(x) for x in opt_val if isinstance(x, int)]

        options_dict[str(opt_key)] = decode_val(opt_val)

    fingerprint_sig = ",".join(str(x.split(":")[0]) for x in option_sequence if x != "255:end")

    return {
        "timestamp": now_iso,
        "iface": iface,
        "eth_src": eth_src,
        "eth_dst": eth_dst,
        "ip_src": ip_src,
        "ip_dst": ip_dst,
        "udp_sport": udp_sport,
        "udp_dport": udp_dport,
        "message_type_code": msg_type_code,
        "message_type": msg_type_str,
        "xid": xid,
        "client_mac": client_mac,
        "ciaddr": ciaddr,
        "yiaddr": yiaddr,
        "siaddr": siaddr,
        "giaddr": giaddr,
        "server_id": server_id,
        "router": router,
        "dns_servers": dns_servers,
        "lease_time": lease_time,
        "subnet_mask": subnet_mask,
        "domain_name": domain_name,
        "requested_addr": requested_addr,
        "option_82": option_82,
        "param_req_list": param_req_list,
        "option_sequence": option_sequence,
        "fingerprint_signature": fingerprint_sig,
        "options": options_dict,
    }

