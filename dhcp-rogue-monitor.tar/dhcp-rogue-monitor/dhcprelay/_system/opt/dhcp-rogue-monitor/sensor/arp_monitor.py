#!/usr/bin/env python3
"""
arp_monitor.py - Scapy ARP Inspection & Baseline Correlation Module
Collects ARP Request (who-has) and ARP Reply (is-at), maintains a dynamic IP-MAC
binding table compared against baseline static bindings (such as the gateway
10.10.0.1 -> 02:42:0a:0a:00:01), and detects MAC changes or IP-MAC conflicts.
"""

from datetime import datetime, timezone
from scapy.all import Ether, ARP


class ARPMonitor:
    def __init__(self, gateway_ip="10.10.0.1", gateway_mac="02:42:0a:0a:00:01", static_bindings=None):
        self.gateway_ip = gateway_ip
        self.gateway_mac = gateway_mac.lower()
        self.static_bindings = {k: v.lower() for k, v in (static_bindings or {}).items()}
        if self.gateway_ip not in self.static_bindings:
            self.static_bindings[self.gateway_ip] = self.gateway_mac

        # ip -> {mac, first_seen, last_seen, packet_count, status, history_macs, is_static}
        self.arp_table = {}
        self.arp_events_count = 0

        now_iso = datetime.now(timezone.utc).isoformat()
        for ip, mac in self.static_bindings.items():
            self.arp_table[ip] = {
                "ip": ip,
                "mac": mac,
                "first_seen": now_iso,
                "last_seen": now_iso,
                "packet_count": 0,
                "status": "TRUSTED_STATIC",
                "history_macs": [mac],
                "is_static": True,
            }

    def process_packet(self, pkt, iface="eth1"):
        """
        Inspect an ARP packet and return a tuple (arp_event_dict, anomaly_list).
        Returns (None, []) if the packet is not ARP.
        """
        if not pkt.haslayer(ARP):
            return None, []

        arp = pkt[ARP]
        now_iso = datetime.now(timezone.utc).isoformat()
        op_code = int(arp.op)
        op_str = "REQUEST" if op_code == 1 else ("REPLY" if op_code == 2 else f"OP_{op_code}")

        sender_ip = str(arp.psrc)
        sender_mac = str(arp.hwsrc).lower()
        target_ip = str(arp.pdst)
        target_mac = str(arp.hwdst).lower()
        eth_src = pkt[Ether].src.lower() if pkt.haslayer(Ether) else sender_mac

        self.arp_events_count += 1
        anomalies = []

        # Ignore 0.0.0.0 ARP probes for table binding updates, though still record event
        if sender_ip and sender_ip != "0.0.0.0":
            # Check against static baseline first (e.g. Gateway MAC spoofing)
            if sender_ip in self.static_bindings:
                expected_mac = self.static_bindings[sender_ip]
                if sender_mac != expected_mac:
                    anomalies.append({
                        "type": "ARP_GATEWAY_OR_STATIC_SPOOF",
                        "severity": "HIGH",
                        "ip": sender_ip,
                        "observed_mac": sender_mac,
                        "expected_mac": expected_mac,
                        "reason": (
                            f"ARP {op_str} claims static IP {sender_ip} is at {sender_mac}, "
                            f"violating baseline MAC {expected_mac}"
                        ),
                    })

            if sender_ip not in self.arp_table:
                self.arp_table[sender_ip] = {
                    "ip": sender_ip,
                    "mac": sender_mac,
                    "first_seen": now_iso,
                    "last_seen": now_iso,
                    "packet_count": 1,
                    "status": "DYNAMIC_NORMAL",
                    "history_macs": [sender_mac],
                    "is_static": False,
                }
            else:
                entry = self.arp_table[sender_ip]
                entry["last_seen"] = now_iso
                entry["packet_count"] += 1
                if sender_mac != entry["mac"]:
                    old_mac = entry["mac"]
                    if sender_mac not in entry["history_macs"]:
                        entry["history_macs"].append(sender_mac)
                    if not entry.get("is_static", False):
                        entry["mac"] = sender_mac
                        entry["status"] = "MAC_CHANGED"
                        anomalies.append({
                            "type": "ARP_IP_MAC_CONFLICT",
                            "severity": "WARNING",
                            "ip": sender_ip,
                            "observed_mac": sender_mac,
                            "expected_mac": old_mac,
                            "reason": (
                                f"IP {sender_ip} changed MAC binding from {old_mac} to {sender_mac} "
                                f"(observed in ARP {op_str})"
                            ),
                        })
                    else:
                        entry["status"] = "SPOOF_ATTEMPTED"

        # Check Ethernet source vs ARP header hwsrc mismatch
        if eth_src != sender_mac:
            anomalies.append({
                "type": "ARP_HEADER_MISMATCH",
                "severity": "WARNING",
                "ip": sender_ip,
                "observed_mac": sender_mac,
                "expected_mac": eth_src,
                "reason": f"Ethernet source MAC ({eth_src}) differs from ARP hwsrc ({sender_mac})",
            })

        arp_event = {
            "timestamp": now_iso,
            "iface": iface,
            "operation": op_str,
            "sender_ip": sender_ip,
            "sender_mac": sender_mac,
            "target_ip": target_ip,
            "target_mac": target_mac,
            "eth_src": eth_src,
            "anomalies_count": len(anomalies),
        }
        return arp_event, anomalies

    def get_mac_for_ip(self, ip_addr):
        entry = self.arp_table.get(ip_addr)
        return entry["mac"] if entry else None

    def get_table_snapshot(self):
        return list(self.arp_table.values())

