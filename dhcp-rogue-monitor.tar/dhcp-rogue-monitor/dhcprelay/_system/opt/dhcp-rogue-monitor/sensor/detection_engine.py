#!/usr/bin/env python3
"""
detection_engine.py - Core DHCP Fingerprinting & ARP Correlation Detection Engine
Classifies events into 4 strict severity levels:
  - INFO: Legitimate DHCP Server matching allowlist and policy baseline.
  - WARNING: Baseline deviation on a known server or minor ARP binding change.
  - HIGH: DHCPOFFER/DHCPACK from an unauthorized Server Identifier (Option 54),
          competing Offers on the same Transaction ID (XID), or unauthorized Router/DNS.
  - CRITICAL: Verified evidence that a Client accepted or was ACKed a malicious
              configuration from an unauthorized Rogue DHCP Server.
"""

from datetime import datetime, timezone
import yaml


class DetectionEngine:
    def __init__(
        self,
        trusted_cfg_path="/etc/dhcp-rogue-monitor/trusted_servers.yaml",
        detection_cfg_path="/etc/dhcp-rogue-monitor/detection.yaml",
        arp_monitor=None,
        event_logger=None,
    ):
        self.trusted_cfg = self._load_yaml(trusted_cfg_path)
        self.detection_cfg = self._load_yaml(detection_cfg_path)
        self.arp_monitor = arp_monitor
        self.logger = event_logger

        self.trusted_servers = {}
        for srv in self.trusted_cfg.get("trusted_dhcp_servers", []):
            sid = str(srv.get("server_identifier", "")).strip()
            if sid:
                self.trusted_servers[sid] = srv

        # State tracking
        self.alerts = []
        self.events = []
        self.observed_servers = {}  # key: server_id -> summary dict
        self.xid_offers = {}        # xid -> list of {server_id, eth_src, yiaddr, router, dns, timestamp}
        self.xid_client_requests = {}  # xid -> {client_mac, requested_server_id, requested_addr, timestamp}

        self.stats = {
            "sensor_status": "RUNNING",
            "started_at": datetime.now(timezone.utc).isoformat(),
            "last_updated": datetime.now(timezone.utc).isoformat(),
            "total_dhcp_packets": 0,
            "discover_count": 0,
            "offer_count": 0,
            "request_count": 0,
            "ack_count": 0,
            "nak_count": 0,
            "release_count": 0,
            "arp_packets": 0,
            "trusted_servers_seen": 0,
            "rogue_servers_seen": 0,
            "alerts_by_severity": {
                "INFO": 0,
                "WARNING": 0,
                "HIGH": 0,
                "CRITICAL": 0,
            },
            "timeline": [],  # list of {time_bucket, dhcp_packets, alerts}
        }

    @staticmethod
    def _load_yaml(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return {}

    def _record_timeline(self, is_dhcp=False, is_alert=False):
        now_bucket = datetime.now(timezone.utc).strftime("%H:%M:%S")
        if self.stats["timeline"] and self.stats["timeline"][-1]["time"] == now_bucket:
            bucket = self.stats["timeline"][-1]
        else:
            bucket = {"time": now_bucket, "dhcp_packets": 0, "alerts": 0}
            self.stats["timeline"].append(bucket)
            if len(self.stats["timeline"]) > 40:
                self.stats["timeline"].pop(0)
        if is_dhcp:
            bucket["dhcp_packets"] += 1
        if is_alert:
            bucket["alerts"] += 1

    def _emit_alert(
        self,
        severity,
        alert_type,
        server_id,
        observed_mac,
        client_mac,
        xid,
        evidence,
        reason,
        confirmation_condition,
    ):
        ts = datetime.now(timezone.utc).isoformat()
        alert_id = f"ALT-{len(self.alerts) + 1:04d}"
        alert = {
            "alert_id": alert_id,
            "timestamp": ts,
            "severity": severity,
            "alert_type": alert_type,
            "server_id": server_id or "N/A",
            "observed_mac": observed_mac or "N/A",
            "client_mac": client_mac or "N/A",
            "xid": xid or "N/A",
            "evidence": evidence,
            "reason": reason,
            "confirmation_condition": confirmation_condition,
        }
        self.alerts.append(alert)
        if severity in self.stats["alerts_by_severity"]:
            self.stats["alerts_by_severity"][severity] += 1
        self._record_timeline(is_dhcp=False, is_alert=(severity in ("WARNING", "HIGH", "CRITICAL")))

        if self.logger:
            self.logger.log_text(
                f"ALERT id={alert_id} SEVERITY={severity} TYPE={alert_type} "
                f"SERVER_ID={server_id} MAC={observed_mac} CLIENT={client_mac} "
                f"XID={xid} REASON=\"{reason}\""
            )
        return alert

    def _update_server_profile(self, fp, is_trusted, classification):
        sid = fp.get("server_id") or fp.get("ip_src") or "unknown"
        msg_type = fp.get("message_type")
        now_iso = fp.get("timestamp")

        if sid not in self.observed_servers:
            relay_ctx = "Direct L2 on EXTERNAL_NET"
            if fp.get("giaddr") and fp.get("giaddr") != "0.0.0.0":
                relay_ctx = f"Relayed via giaddr {fp.get('giaddr')} (Relay MAC {fp.get('eth_src')})"
            elif fp.get("eth_src") == "02:42:0a:0a:00:01" and sid == "192.168.0.100":
                relay_ctx = "Relayed via dhcprelay (eth1 02:42:0a:0a:00:01)"

            self.observed_servers[sid] = {
                "server_id": sid,
                "observed_mac": fp.get("eth_src"),
                "ip_src": fp.get("ip_src"),
                "relay_context": relay_ctx,
                "router_offered": fp.get("router") or "N/A",
                "dns_offered": ", ".join(fp.get("dns_servers") or []) or "N/A",
                "lease_time": fp.get("lease_time") or "N/A",
                "domain_name": fp.get("domain_name") or "N/A",
                "fingerprint_signature": fp.get("fingerprint_signature") or "",
                "offer_count": 0,
                "ack_count": 0,
                "nak_count": 0,
                "first_seen": now_iso,
                "last_seen": now_iso,
                "status": "TRUSTED" if is_trusted else "ROGUE",
                "classification": classification,
            }
        srv = self.observed_servers[sid]
        srv["last_seen"] = now_iso
        srv["observed_mac"] = fp.get("eth_src") or srv["observed_mac"]
        if fp.get("router"):
            srv["router_offered"] = fp.get("router")
        if fp.get("dns_servers"):
            srv["dns_offered"] = ", ".join(fp.get("dns_servers"))
        if fp.get("lease_time"):
            srv["lease_time"] = fp.get("lease_time")
        if fp.get("fingerprint_signature"):
            srv["fingerprint_signature"] = fp.get("fingerprint_signature")
        if not is_trusted:
            srv["status"] = "ROGUE"
            srv["classification"] = classification

        if msg_type == "OFFER":
            srv["offer_count"] += 1
        elif msg_type == "ACK":
            srv["ack_count"] += 1
        elif msg_type == "NAK":
            srv["nak_count"] += 1

        self.stats["trusted_servers_seen"] = sum(
            1 for s in self.observed_servers.values() if s["status"] == "TRUSTED"
        )
        self.stats["rogue_servers_seen"] = sum(
            1 for s in self.observed_servers.values() if s["status"] == "ROGUE"
        )

    def handle_arp_packet(self, pkt, iface="eth1"):
        if not self.arp_monitor:
            return
        arp_ev, anomalies = self.arp_monitor.process_packet(pkt, iface=iface)
        if not arp_ev:
            return
        self.stats["arp_packets"] = self.arp_monitor.arp_events_count
        self.stats["last_updated"] = arp_ev["timestamp"]

        for anom in anomalies:
            self._emit_alert(
                severity=anom["severity"],
                alert_type=anom["type"],
                server_id=anom["ip"],
                observed_mac=anom["observed_mac"],
                client_mac="ff:ff:ff:ff:ff:ff",
                xid="ARP",
                evidence=arp_ev,
                reason=anom["reason"],
                confirmation_condition="Verified against static/dynamic ARP baseline table",
            )
        self._flush()

    def handle_dhcp_fingerprint(self, fp):
        if not fp:
            return
        self.stats["total_dhcp_packets"] += 1
        self.stats["last_updated"] = fp["timestamp"]
        self._record_timeline(is_dhcp=True, is_alert=False)

        mtype = fp["message_type"]
        if mtype == "DISCOVER":
            self.stats["discover_count"] += 1
        elif mtype == "OFFER":
            self.stats["offer_count"] += 1
        elif mtype == "REQUEST":
            self.stats["request_count"] += 1
        elif mtype == "ACK":
            self.stats["ack_count"] += 1
        elif mtype == "NAK":
            self.stats["nak_count"] += 1
        elif mtype == "RELEASE":
            self.stats["release_count"] += 1

        self.events.append(fp)

        xid = fp["xid"]
        client_mac = fp["client_mac"]
        eth_src = fp["eth_src"]
        sid = fp.get("server_id") or fp.get("ip_src")

        # Track Client REQUEST to see which Server Identifier the client selected
        if mtype == "REQUEST":
            self.xid_client_requests[xid] = {
                "client_mac": client_mac,
                "requested_server_id": fp.get("server_id"),
                "requested_addr": fp.get("requested_addr") or fp.get("ciaddr"),
                "timestamp": fp["timestamp"],
            }
            req_sid = fp.get("server_id")
            if req_sid and req_sid not in self.trusted_servers:
                self._emit_alert(
                    severity="HIGH",
                    alert_type="CLIENT_REQUESTING_ROGUE_SERVER",
                    server_id=req_sid,
                    observed_mac=eth_src,
                    client_mac=client_mac,
                    xid=xid,
                    evidence={
                        "message_type": "REQUEST",
                        "requested_server_id": req_sid,
                        "requested_addr": fp.get("requested_addr"),
                        "option_sequence": fp.get("option_sequence"),
                    },
                    reason=(
                        f"Client {client_mac} sent DHCPREQUEST selecting unauthorized "
                        f"Server Identifier {req_sid} (requested IP {fp.get('requested_addr')})"
                    ),
                    confirmation_condition="Elevate to CRITICAL if Rogue Server completes handshake with DHCPACK",
                )

        # Evaluate Server responses: OFFER, ACK, NAK
        if mtype in ("OFFER", "ACK", "NAK"):
            is_allowlisted = sid in self.trusted_servers
            baseline = self.trusted_servers.get(sid, {})

            deviations = []
            if is_allowlisted:
                exp_mac = str(baseline.get("observed_external_mac", "")).lower()
                exp_internal_mac = str(baseline.get("server_internal_mac", "")).lower()
                if exp_mac and eth_src not in (exp_mac, exp_internal_mac):
                    deviations.append(
                        f"Observed Ethernet source MAC {eth_src} does not match expected Relay/Server MAC ({exp_mac})"
                    )
                exp_router = baseline.get("allowed_router")
                if fp.get("router") and exp_router and fp.get("router") != exp_router:
                    deviations.append(f"Router Option 3 ({fp.get('router')}) != baseline ({exp_router})")
                exp_dns = baseline.get("allowed_dns_servers", [])
                if fp.get("dns_servers") and exp_dns and set(fp.get("dns_servers")) != set(exp_dns):
                    deviations.append(f"DNS Option 6 ({fp.get('dns_servers')}) != baseline ({exp_dns})")

            if is_allowlisted and not deviations:
                self._update_server_profile(fp, is_trusted=True, classification="Authorized ISC DHCP Server")
                self._emit_alert(
                    severity="INFO",
                    alert_type=f"AUTHORIZED_DHCP_{mtype}",
                    server_id=sid,
                    observed_mac=eth_src,
                    client_mac=client_mac,
                    xid=xid,
                    evidence={
                        "yiaddr": fp.get("yiaddr"),
                        "router": fp.get("router"),
                        "dns_servers": fp.get("dns_servers"),
                        "lease_time": fp.get("lease_time"),
                        "fingerprint": fp.get("fingerprint_signature"),
                    },
                    reason=(
                        f"Legitimate DHCP {mtype} from allowlisted server {sid} "
                        f"(yiaddr={fp.get('yiaddr')}, router={fp.get('router')}, dns={fp.get('dns_servers')})"
                    ),
                    confirmation_condition="Matches trusted_servers.yaml baseline",
                )
            elif is_allowlisted and deviations:
                # Could be a spoofed Server Identifier from a rogue host or misconfiguration
                exp_mac = str(baseline.get("observed_external_mac", "")).lower()
                is_mac_spoof = exp_mac and eth_src != exp_mac
                sev = "HIGH" if is_mac_spoof else "WARNING"
                self._update_server_profile(
                    fp,
                    is_trusted=not is_mac_spoof,
                    classification="Spoofed Server ID / Policy Deviation" if is_mac_spoof else "Policy Deviation",
                )
                self._emit_alert(
                    severity=sev,
                    alert_type="DHCP_BASELINE_DEVIATION",
                    server_id=sid,
                    observed_mac=eth_src,
                    client_mac=client_mac,
                    xid=xid,
                    evidence={
                        "deviations": deviations,
                        "yiaddr": fp.get("yiaddr"),
                        "router": fp.get("router"),
                        "dns_servers": fp.get("dns_servers"),
                    },
                    reason="; ".join(deviations),
                    confirmation_condition="Inspect L2 source MAC and DHCP server configuration",
                )
            else:
                # Unauthorized Server Identifier -> Rogue DHCP Server!
                arp_corr = None
                if self.arp_monitor:
                    arp_mac = self.arp_monitor.get_mac_for_ip(sid)
                    arp_corr = (
                        f"ARP table binds {sid} -> {arp_mac}"
                        if arp_mac
                        else f"No abnormal ARP spoofing required; rogue server operating directly at L2 MAC {eth_src}"
                    )

                policy_violations = [f"Unauthorized Server Identifier Option 54 ({sid}) not in allowlist"]
                if fp.get("router") and fp.get("router") != "10.10.0.1":
                    policy_violations.append(f"Rogue Router Option 3 ({fp.get('router')} != 10.10.0.1)")
                if fp.get("dns_servers") and "192.168.0.100" not in fp.get("dns_servers"):
                    policy_violations.append(f"Rogue DNS Option 6 ({fp.get('dns_servers')} != [192.168.0.100])")

                self._update_server_profile(
                    fp,
                    is_trusted=False,
                    classification="Unauthorized Rogue DHCP Server",
                )

                if mtype == "OFFER":
                    # Offer from unauthorized server -> HIGH (never CRITICAL on Offer alone)
                    self._emit_alert(
                        severity="HIGH",
                        alert_type="ROGUE_DHCP_OFFER_DETECTED",
                        server_id=sid,
                        observed_mac=eth_src,
                        client_mac=client_mac,
                        xid=xid,
                        evidence={
                            "message_type": "OFFER",
                            "yiaddr": fp.get("yiaddr"),
                            "router": fp.get("router"),
                            "dns_servers": fp.get("dns_servers"),
                            "lease_time": fp.get("lease_time"),
                            "fingerprint": fp.get("fingerprint_signature"),
                            "arp_correlation": arp_corr,
                        },
                        reason="; ".join(policy_violations),
                        confirmation_condition=(
                            "HIGH alert on unauthorized DHCPOFFER. Escalates to CRITICAL only if "
                            "DHCPACK is issued or Client configures the rogue lease."
                        ),
                    )
                elif mtype == "ACK":
                    # DHCPACK from unauthorized server -> CRITICAL (verified client impact / lease completion)
                    req_info = self.xid_client_requests.get(xid)
                    self._emit_alert(
                        severity="CRITICAL",
                        alert_type="ROGUE_DHCP_ACK_CLIENT_COMPROMISED",
                        server_id=sid,
                        observed_mac=eth_src,
                        client_mac=client_mac,
                        xid=xid,
                        evidence={
                            "message_type": "ACK",
                            "compromised_client_mac": client_mac,
                            "assigned_rogue_ip": fp.get("yiaddr"),
                            "rogue_gateway": fp.get("router"),
                            "rogue_dns": fp.get("dns_servers"),
                            "lease_time": fp.get("lease_time"),
                            "client_request_seen": bool(req_info),
                            "fingerprint": fp.get("fingerprint_signature"),
                            "arp_correlation": arp_corr,
                        },
                        reason=(
                            f"CRITICAL: Rogue DHCP Server {sid} ({eth_src}) completed DHCPACK to client "
                            f"{client_mac} with IP {fp.get('yiaddr')}, rogue gateway {fp.get('router')}, "
                            f"and rogue DNS {fp.get('dns_servers')}"
                        ),
                        confirmation_condition=(
                            "Confirmed via captured DHCPACK from unauthorized Server Identifier "
                            "delivering malicious gateway/DNS parameters to client"
                        ),
                    )

            # Check for Multiple Competing Offers on the same Transaction ID (XID)
            if mtype == "OFFER":
                offers = self.xid_offers.setdefault(xid, [])
                offers.append({
                    "server_id": sid,
                    "eth_src": eth_src,
                    "yiaddr": fp.get("yiaddr"),
                    "router": fp.get("router"),
                    "dns": fp.get("dns_servers"),
                    "is_trusted": is_allowlisted,
                })
                distinct_sids = {o["server_id"] for o in offers}
                has_untrusted = any(not o["is_trusted"] for o in offers)
                if len(distinct_sids) > 1 and has_untrusted:
                    self._emit_alert(
                        severity="HIGH",
                        alert_type="COMPETING_DHCP_OFFERS_SAME_XID",
                        server_id=",".join(sorted(distinct_sids)),
                        observed_mac=eth_src,
                        client_mac=client_mac,
                        xid=xid,
                        evidence={"competing_offers": offers},
                        reason=(
                            f"Multiple DHCP Servers ({', '.join(sorted(distinct_sids))}) responded with "
                            f"DHCPOFFER to the same client transaction XID {xid}, including an unauthorized server"
                        ),
                        confirmation_condition="Race condition between legitimate Relay Offer and local L2 Rogue Offer",
                    )

        self._flush()

    def _flush(self):
        if self.logger:
            arp_snap = self.arp_monitor.get_table_snapshot() if self.arp_monitor else []
            self.logger.sync_state(
                alerts=self.alerts,
                events=self.events,
                servers=self.observed_servers,
                arp_table=arp_snap,
                stats=self.stats,
            )

