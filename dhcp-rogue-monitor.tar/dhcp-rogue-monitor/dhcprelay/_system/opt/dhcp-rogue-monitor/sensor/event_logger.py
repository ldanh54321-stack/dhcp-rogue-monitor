#!/usr/bin/env python3
"""
event_logger.py - Thread-safe Structured Event & Alert Logger
Writes real-time JSON snapshots for the Web Dashboard and text logs for Labtainers checkwork.
"""

import json
import os
import threading
from datetime import datetime, timezone


class EventLogger:
    def __init__(
        self,
        log_dir="/var/log/dhcp-rogue-monitor",
        detection_log="/var/log/dhcp_rogue_detection.log",
    ):
        self.log_dir = log_dir
        self.detection_log = detection_log
        self.alerts_file = os.path.join(log_dir, "alerts.json")
        self.events_file = os.path.join(log_dir, "events.json")
        self.servers_file = os.path.join(log_dir, "servers.json")
        self.arp_table_file = os.path.join(log_dir, "arp_table.json")
        self.stats_file = os.path.join(log_dir, "stats.json")
        self._lock = threading.Lock()

        os.makedirs(self.log_dir, exist_ok=True)
        for path in [
            self.alerts_file,
            self.events_file,
            self.servers_file,
            self.arp_table_file,
            self.stats_file,
        ]:
            if not os.path.exists(path):
                self._atomic_write_json(path, [])
            try:
                os.chmod(path, 0o666)
            except OSError:
                pass

        if not os.path.exists(self.detection_log):
            with open(self.detection_log, "a", encoding="utf-8"):
                pass
        try:
            os.chmod(self.detection_log, 0o666)
        except OSError:
            pass

    def _atomic_write_json(self, filepath, data):
        tmp_path = f"{filepath}.tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp_path, filepath)
        try:
            os.chmod(filepath, 0o666)
        except OSError:
            pass

    def log_text(self, line):
        ts = datetime.now(timezone.utc).isoformat()
        entry = f"[{ts}] {line}\n"
        with self._lock:
            with open(self.detection_log, "a", encoding="utf-8") as f:
                f.write(entry)

    def sync_state(self, alerts, events, servers, arp_table, stats):
        with self._lock:
            # Keep bounded ring buffer so files never grow infinitely
            self._atomic_write_json(self.alerts_file, alerts[-200:])
            self._atomic_write_json(self.events_file, events[-300:])
            self._atomic_write_json(self.servers_file, list(servers.values()))
            self._atomic_write_json(self.arp_table_file, arp_table)
            self._atomic_write_json(self.stats_file, stats)

