#!/usr/bin/env python3
"""
dhcp_sniffer.py - Real-time Scapy DHCP Fingerprinting & ARP Monitoring Sensor Daemon
Listens on the external broadcast domain interface (eth1 - 10.10.0.0/24) on dhcprelay,
parses all DHCP (ports 67/68) and ARP frames, feeds the DetectionEngine, and maintains
real-time JSON state and detection logs.
"""

import argparse
import os
import signal
import subprocess
import sys
import yaml
from scapy.all import sniff, ARP, DHCP, BOOTP

SENSOR_DIR = os.path.dirname(os.path.abspath(__file__))
if SENSOR_DIR not in sys.path:
    sys.path.insert(0, SENSOR_DIR)

from dhcp_fingerprint import extract_dhcp_fingerprint
from arp_monitor import ARPMonitor
from event_logger import EventLogger
from detection_engine import DetectionEngine

RUNNING = True


def detect_external_iface(default_iface="eth1"):
    """Auto-detect the interface carrying 10.10.0.1/24 on dhcprelay."""
    try:
        out = subprocess.check_output(["ip", "-o", "-4", "addr", "show"], text=True)
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 4 and parts[3].startswith("10.10.0."):
                return parts[1]
    except Exception:
        pass
    return default_iface


def handle_sig(signum, frame):
    global RUNNING
    RUNNING = False


def main():
    parser = argparse.ArgumentParser(description="Scapy DHCP Fingerprinting & ARP Monitoring Sensor")
    parser.add_argument("--iface", default=None, help="Network interface to monitor (default: auto-detect eth1)")
    parser.add_argument(
        "--trusted-config",
        default="/etc/dhcp-rogue-monitor/trusted_servers.yaml",
        help="Path to trusted_servers.yaml",
    )
    parser.add_argument(
        "--detection-config",
        default="/etc/dhcp-rogue-monitor/detection.yaml",
        help="Path to detection.yaml",
    )
    args = parser.parse_args()

    signal.signal(signal.SIGINT, handle_sig)
    signal.signal(signal.SIGTERM, handle_sig)

    iface = args.iface or detect_external_iface("eth1")

    try:
        with open(args.trusted_config, "r", encoding="utf-8") as f:
            trusted_cfg = yaml.safe_load(f) or {}
    except Exception:
        trusted_cfg = {}

    arp_cfg = trusted_cfg.get("arp_baseline", {})
    arp_mon = ARPMonitor(
        gateway_ip=arp_cfg.get("gateway_ip", "10.10.0.1"),
        gateway_mac=arp_cfg.get("gateway_mac", "02:42:0a:0a:00:01"),
        static_bindings=arp_cfg.get("static_bindings", {}),
    )
    logger = EventLogger(
        log_dir="/var/log/dhcp-rogue-monitor",
        detection_log="/var/log/dhcp_rogue_detection.log",
    )
    engine = DetectionEngine(
        trusted_cfg_path=args.trusted_config,
        detection_cfg_path=args.detection_config,
        arp_monitor=arp_mon,
        event_logger=logger,
    )

    logger.log_text(f"SENSOR_ENGINE_ACTIVE iface={iface} pid={os.getpid()}")
    engine._flush()

    print(f"[*] Scapy DHCP Fingerprinting & ARP Sensor active on interface '{iface}' (PID {os.getpid()})")

    def packet_callback(pkt):
        try:
            if pkt.haslayer(DHCP) and pkt.haslayer(BOOTP):
                fp = extract_dhcp_fingerprint(pkt, iface=iface)
                if fp:
                    engine.handle_dhcp_fingerprint(fp)
            elif pkt.haslayer(ARP):
                engine.handle_arp_packet(pkt, iface=iface)
        except Exception as exc:
            logger.log_text(f"SENSOR_PACKET_ERROR err={exc}")

    sniff(
        iface=iface,
        filter="(udp and (port 67 or port 68)) or arp",
        prn=packet_callback,
        store=False,
        stop_filter=lambda p: not RUNNING,
    )

    engine.stats["sensor_status"] = "STOPPED"
    engine._flush()
    logger.log_text(f"SENSOR_ENGINE_STOPPED iface={iface}")


if __name__ == "__main__":
    main()

