# BÁO CÁO KIỂM THỬ HỆ THỐNG (`TEST_REPORT.md`) — `dhcp-rogue-monitor`

## 1. Thông tin Môi trường Kiểm thử
- **Hệ điều hành Host**: Ubuntu Linux (`x86_64`)
- **Framework**: Labtainers (`trunk`)
- **Tên Module Labtainers**: `dhcp-rogue-monitor`
- **Kiến trúc mạng**: Dual-Subnet (`INTERNAL_NET: 192.168.0.0/24`, `EXTERNAL_NET: 10.10.0.0/24`)
- **Danh sách 4 Containers**:
  - `dhcpserver` (`zeus183/dhcp-rogue-monitor.dhcpserver.student:latest`) — `192.168.0.100` (`02:42:c0:a8:00:64`)
  - `dhcprelay` (`zeus183/dhcp-rogue-monitor.dhcprelay.student:latest`) — `192.168.0.1` (`02:42:c0:a8:00:01`) & `10.10.0.1` (`02:42:0a:0a:00:01`)
  - `attacker` (`zeus183/dhcp-rogue-monitor.attacker.student:latest`) — `10.10.0.20` (`02:42:0a:0a:00:14`)
  - `client` (`zeus183/dhcp-rogue-monitor.client.student:latest`) — Dynamic DHCP (`02:42:0a:0a:00:32`)

---

## 2. Bảng Kết quả Kiểm thử Bắt buộc

| Mã Test | Hạng mục Kiểm thử | Trạng thái | Bằng chứng Thực nghiệm |
| :--- | :--- | :---: | :--- |
| **T01** | Khởi chạy bài lab bằng `labtainer -r dhcp-rogue-monitor` | **PASS** | Cả 4 container khởi tạo thành công (`Started 4 containers, 4 completed initialization. Done.`) |
| **T02** | Cấp phát IP hợp lệ ở giai đoạn Baseline (`dhcpserver` -> `dhcprelay` -> `client`) | **PASS** | `client` nhận IP `10.10.0.100`, Gateway `10.10.0.1`, Server ID `192.168.0.100` trong `1873 ms`. |
| **T03** | Scapy DHCP Fingerprinting nhận diện đúng Server hợp lệ, không báo giả | **PASS** | Ghi nhận `[TRUSTED] Server ID=192.168.0.100 | L2 MAC=02:42:0a:0a:00:01 | OptSeq=53,54,51,1,3,15,6` với `CRITICAL=0, HIGH=0, WARNING=0, INFO=4`. |
| **T04** | Kịch bản Kali Rogue DHCP Server hoạt động trong mạng cô lập `EXTERNAL_NET` | **PASS** | `start-rogue.sh` phát `DHCPOFFER` / `DHCPACK` giả mạo với `Server ID=10.10.0.20`, `yiaddr=10.10.0.200`, `Router=10.10.0.20`, `DNS=10.10.0.20`, `OptSeq=53,54,51,1,3,6,15`. |
| **T05** | Detection Engine phát hiện Rogue DHCP & Competing Offers cùng `XID` | **PASS** | Sinh cảnh báo `HIGH` (`ROGUE_DHCP_OFFER_DETECTED`, `COMPETING_DHCP_OFFERS_SAME_XID`, `CLIENT_REQUESTING_ROGUE_SERVER`) và `CRITICAL` khi Rogue hoàn tất `DHCPACK`. |
| **T06** | Giám sát ARP (`arp_monitor.py`) ghi nhận bảng IP-MAC thực tế | **PASS** | Ghi nhận chính xác `10.10.0.1 -> 02:42:0a:0a:00:01 (TRUSTED_STATIC)`, `10.10.0.100 -> 02:42:0a:0a:00:32`, `10.10.0.20 -> 02:42:0a:0a:00:14`. |
| **T07** | Web Dashboard (`http://10.10.0.1:5000`) hoạt động offline, trả về dữ liệu thật | **PASS** | Endpoint `/api/summary`, `/api/alerts`, `/api/servers`, `/api/arp` trả về HTTP 200 kèm JSON thực tế. |
| **T08** | Thu thập đủ 3 file PCAPNG mở được bằng Wireshark/TShark | **PASS** | `normal.pcapng` (2968B, 10 pkts), `rogue_attack.pcapng` (3192B, 9 pkts), `recovery.pcapng` (3184B, 9 pkts). |
| **T09** | Dừng Rogue Server & Khôi phục cấu hình DHCP hợp lệ trên `client` | **PASS** | `stop-rogue.sh` dừng tiến trình rogue; `client-test.sh recovery` nhận lại IP `10.10.0.100`, GW `10.10.0.1` từ `192.168.0.100`. |
| **T10** | Chấm điểm tự động với `checkwork dhcp-rogue-monitor` | **PASS** | Đạt **7/7** mục tiêu (`Y`): `client_baseline_ip`, `sensor_active`, `rogue_attack_run`, `rogue_detected`, `pcap_captured`, `client_recovered`, `report_generated`. |
| **T11** | Đóng gói `dhcp-rogue-monitor.tar` và kiểm thử `imodule` môi trường sạch | **PASS** | `validate-package.sh` (0 lỗi) và `test-import.sh` import thành công qua `imodule`. |

---

## 3. Các vấn đề phát hiện và đã khắc phục trong quá trình kiểm thử
1. **Thời gian khởi tạo Scapy trên `attacker`**: Khi chạy `start-rogue.sh`, Scapy mất khoảng 1.5–2 giây để mở raw socket trên `eth0`. Đã cập nhật `start-rogue.sh` chờ xác nhận dòng `ROGUE_SERVER_STARTED` trong `/var/log/rogue_dhcp.log` trước khi trả về prompt để đảm bảo khi sinh viên chạy `client-test.sh attack` ngay lập tức thì Rogue Server đã sẵn sàng 100%.
2. **Làm sạch log kế thừa từ base image `attacker`**: Đã thêm `: > /var/log/rogue_dhcp.log` trong `Dockerfile.dhcp-rogue-monitor.attacker.student` để xóa mọi dòng log cũ từ image gốc.
