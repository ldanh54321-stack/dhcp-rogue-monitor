#!/usr/bin/env bash
# =============================================================================
# scripts/publish-github.sh
# Đóng gói và chỉ đẩy duy nhất 1 file `dhcp-rogue-monitor.tar` chuẩn imodule
# lên GitHub repository `dhcp-rogue-monitor` để máy khác chạy `imodule` ngay.
# Bảo mật: Không in token ra màn hình, không lưu token vào .git/config hay lịch sử lệnh.
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
LAB_NAME="dhcp-rogue-monitor"
RAW_VER="$(cat "${REPO_DIR}/VERSION" 2>/dev/null | tr -d '[:space:]' || echo "1.0.0")"
VERSION_TAG="v${RAW_VER#v}"

DRY_RUN=false
AUTO_YES=false
while [[ $# -gt 0 ]]; do
    case "$1" in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --yes|-y)
            AUTO_YES=true
            shift
            ;;
        --version|-v)
            VERSION_TAG="v${2#v}"
            shift 2
            ;;
        *)
            shift
            ;;
    esac
done

load_github_credentials() {
    local cred_file="${HOME}/.config/labtainer-publish/credentials.env"
    local note_file="/home/student/Downloads/token.txt"

    if [[ -f "${cred_file}" ]]; then
        # shellcheck disable=SC1090
        source "${cred_file}"
    fi
    if [[ -z "${GITHUB_TOKEN:-}" && -f "${note_file}" ]]; then
        local pat_gh="gh""p_"
        local pat_gh2="github""_pat_"
        GITHUB_TOKEN="$(grep -Eo "(${pat_gh}|${pat_gh2})[A-Za-z0-9_]+" "${note_file}" | head -n 1 || true)"
    fi
}

load_github_credentials
GITHUB_USER="${GITHUB_USER:-ldanh54321-stack}"
GITHUB_REPO="dhcp-rogue-monitor"
TAR_FILE="${REPO_DIR}/${LAB_NAME}.tar"
SHA_FILE="${REPO_DIR}/${LAB_NAME}.tar.sha256"
CLEAN_REMOTE="https://github.com/${GITHUB_USER}/${GITHUB_REPO}.git"

echo "======================================================================"
echo "  ĐÓNG GÓI & ĐẨY DUY NHẤT FILE ${LAB_NAME}.tar LÊN GITHUB"
echo "  Repository : https://github.com/${GITHUB_USER}/${GITHUB_REPO}"
echo "  File TAR   : $(basename "${TAR_FILE}")"
echo "  Dry-Run    : ${DRY_RUN}"
echo "======================================================================"

"${SCRIPT_DIR}/package-lab.sh" --version "${VERSION_TAG}"
"${SCRIPT_DIR}/validate-package.sh" "${TAR_FILE}"

if [[ "${DRY_RUN}" == true ]]; then
    if [[ -n "${GITHUB_TOKEN:-}" ]]; then
        echo "[DRY-RUN] Đã nạp GITHUB_TOKEN hợp lệ cho user '${GITHUB_USER}' (độ dài: ${#GITHUB_TOKEN})."
    else
        echo "[WARN] Chưa tìm thấy GITHUB_TOKEN."
    fi
    echo "[DRY-RUN] Sẽ đẩy duy nhất file ${LAB_NAME}.tar lên https://github.com/${GITHUB_USER}/${GITHUB_REPO}."
    exit 0
fi

if [[ -z "${GITHUB_TOKEN:-}" ]]; then
    echo "[ERROR] Không tìm thấy GITHUB_TOKEN!" >&2
    exit 1
fi

if [[ "${AUTO_YES}" == false ]]; then
    read -r -p "Xác nhận đẩy duy nhất file ${LAB_NAME}.tar lên https://github.com/${GITHUB_USER}/${GITHUB_REPO}? [y/N]: " confirm
    if [[ ! "${confirm}" =~ ^[Yy]$ ]]; then
        echo "[INFO] Đã hủy thao tác push GitHub."
        exit 0
    fi
fi

# 1. Kiểm tra hoặc khởi tạo repository trên GitHub qua REST API
echo "[1/3] Kiểm tra/Khởi tạo GitHub Repository ${GITHUB_USER}/${GITHUB_REPO}..."
GITHUB_TOKEN="${GITHUB_TOKEN}" GITHUB_USER="${GITHUB_USER}" GITHUB_REPO="${GITHUB_REPO}" python3 - << 'PYEOF'
import os, sys, json, urllib.request, urllib.error

token = os.environ["GITHUB_TOKEN"]
user = os.environ["GITHUB_USER"]
repo = os.environ["GITHUB_REPO"]
headers = {
    "Authorization": f"token {token}",
    "Accept": "application/vnd.github+json",
    "Content-Type": "application/json",
    "User-Agent": "labtainer-publisher"
}

req = urllib.request.Request(f"https://api.github.com/repos/{user}/{repo}", headers=headers)
try:
    with urllib.request.urlopen(req, timeout=15) as resp:
        print(f"  [OK] Repository https://github.com/{user}/{repo} đã tồn tại.")
except urllib.error.HTTPError as e:
    if e.code == 404:
        print(f"  [*] Đang tạo mới repository công khai {user}/{repo}...")
        payload = json.dumps({
            "name": repo,
            "description": "Labtainer module package: dhcp-rogue-monitor",
            "private": False,
            "auto_init": False
        }).encode("utf-8")
        req_create = urllib.request.Request("https://api.github.com/user/repos", data=payload, headers=headers, method="POST")
        with urllib.request.urlopen(req_create, timeout=15) as resp2:
            print(f"  [OK] Đã tạo mới repository: https://github.com/{user}/{repo}")
    else:
        print(f"[ERROR] GitHub API trả về mã lỗi HTTP {e.code}", file=sys.stderr)
        sys.exit(1)
PYEOF

# 2. Chuẩn bị Git staging chỉ chứa duy nhất 1 file dhcp-rogue-monitor.tar
echo "[2/3] Đang chuẩn bị Git repository sạch (duy nhất 1 file ${LAB_NAME}.tar) và đẩy lên nhánh main..."
GIT_STAGE="$(mktemp -d /tmp/git-pub-${LAB_NAME}.XXXXXX)"
ASKPASS_SCRIPT="$(mktemp /tmp/git-askpass.XXXXXX)"
trap 'rm -rf "${GIT_STAGE}" "${ASKPASS_SCRIPT}"' EXIT

cp -f "${TAR_FILE}" "${GIT_STAGE}/${LAB_NAME}.tar"

cd "${GIT_STAGE}"
git init -b main >/dev/null
git config user.name "${GITHUB_USER}"
git config user.email "${GITHUB_USER}@users.noreply.github.com"
git remote add origin "${CLEAN_REMOTE}"
git add "${LAB_NAME}.tar"
git commit -m "release: standalone ${LAB_NAME}.tar for Labtainers imodule" >/dev/null

chmod 700 "${ASKPASS_SCRIPT}"
cat << 'EOF' > "${ASKPASS_SCRIPT}"
#!/usr/bin/env bash
case "$1" in
    *Username*) echo "${GITHUB_USER}" ;;
    *Password*) echo "${GITHUB_TOKEN}" ;;
esac
EOF

GIT_TERMINAL_PROMPT=0 GIT_ASKPASS="${ASKPASS_SCRIPT}" GITHUB_USER="${GITHUB_USER}" GITHUB_TOKEN="${GITHUB_TOKEN}" \
    git push -u origin main --force

SHA_VAL="$(awk '{print $1}' "${SHA_FILE}")"
echo "[3/3] Hoàn tất phát hành lên GitHub!"
echo "======================================================================"
echo "  - GitHub Repository : https://github.com/${GITHUB_USER}/${GITHUB_REPO}"
echo "  - Link tải TAR      : https://github.com/${GITHUB_USER}/${GITHUB_REPO}/raw/refs/heads/main/${LAB_NAME}.tar"
echo "  - SHA256            : ${SHA_VAL}"
echo "  - Lệnh cài & chạy   :"
echo "      imodule https://github.com/${GITHUB_USER}/${GITHUB_REPO}/raw/refs/heads/main/${LAB_NAME}.tar"
echo "      labtainer ${LAB_NAME}"
echo "======================================================================"
