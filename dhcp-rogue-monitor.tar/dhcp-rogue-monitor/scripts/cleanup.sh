#!/usr/bin/env bash
# =============================================================================
# scripts/cleanup.sh - Dọn dẹp an toàn chỉ các tài nguyên thuộc bài lab dhcp-rogue-monitor
# Tuyệt đối không xóa image hay network của các bài lab khác
# =============================================================================
set -euo pipefail

cd /home/student/labtainer/trunk/scripts/labtainer-student
./bin/stoplab dhcp-rogue-monitor 2>/dev/null || true

for c in $(docker ps -a --format "{{.Names}}" | grep -E "^dhcp-rogue-monitor(\.|-igrader)" || true); do
    docker rm -f "$c" 2>/dev/null || true
done

for n in $(docker network ls --format "{{.Name}}" | grep "^dhcp-rogue-monitor_" || true); do
    docker network rm "$n" 2>/dev/null || true
done

echo "[OK] Đã dọn dẹp sạch các container/network tạm của bài lab dhcp-rogue-monitor."

