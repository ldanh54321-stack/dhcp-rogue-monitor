# Labtainer: Phát hiện Máy chủ DHCP Giả mạo bằng Phân tích Đặc trưng DHCP & Giám sát ARP (`dhcp-rogue-monitor`)

- **Tên dự án:** DHCP Rogue Server Detection Using DHCP Fingerprinting & ARP Monitoring
- **Tên module Labtainers:** `dhcp-rogue-monitor`
- **Phiên bản:** `v1.0.0`
- **GitHub Repository:** [https://github.com/ldanh54321-stack/dhcp-rogue-monitor](https://github.com/ldanh54321-stack/dhcp-rogue-monitor)
- **GitHub Release (`v1.0.0`):** [https://github.com/ldanh54321-stack/dhcp-rogue-monitor/releases/tag/v1.0.0](https://github.com/ldanh54321-stack/dhcp-rogue-monitor/releases/tag/v1.0.0)
- **Link tải `dhcp-rogue-monitor.tar`:** `https://github.com/ldanh54321-stack/dhcp-rogue-monitor/releases/download/v1.0.0/dhcp-rogue-monitor.tar`
- **Docker Hub chính:** [https://hub.docker.com/r/zeus183/dhcp-rogue-monitor](https://hub.docker.com/r/zeus183/dhcp-rogue-monitor)

---

## 1. Giới thiệu Bài Lab

Bài thực hành **`dhcp-rogue-monitor`** được thiết kế trên nền tảng **Labtainers** nhằm giúp người học thực hành phát hiện **Máy chủ DHCP giả mạo (Rogue DHCP Server)** trong kiến trúc mạng phân tách 2 subnet (**Dual-Subnet qua DHCP Relay**) bằng 2 cơ chế chủ đạo:
1. **Scapy DHCP Option Fingerprinting:** Phân tích chi tiết từng gói tin `DHCPDISCOVER`, `DHCPOFFER`, `DHCPREQUEST`, `DHCPACK`, `DHCPNAK`, `DHCPRELEASE`; đối chiếu `Server Identifier (Option 54)`, `Router (Option 3)`, `DNS (Option 6)`, `Lease Time (Option 51)`, `Transaction ID (XID)`, `giaddr`, địa chỉ MAC nguồn Ethernet và chuỗi thứ tự mã tùy chọn (`Option Fingerprint`: `53,54,51,1,3,15,6` vs `53,54,51,1,3,6,15`) với danh sách cho phép (`trusted_servers.yaml`).
2. **Real-Time ARP Monitoring & Correlation:** Giám sát gói tin `ARP Request` và `ARP Reply` bằng Scapy, xây dựng bảng ánh xạ `IP - MAC` cơ sở (đặc biệt là Default Gateway `10.10.0.1 -> 02:42:0a:0a:00:01`), phát hiện xung đột địa chỉ hoặc thay đổi MAC bất thường và tương quan với cảnh báo DHCP.

Toàn bộ kết quả phân tích được hiển thị trực quan theo thời gian thực trên **Web Dashboard (`http://10.10.0.1:5000`)**, đồng thời lưu trữ chứng cứ số dưới dạng 3 file **PCAPNG** (`normal.pcapng`, `rogue_attack.pcapng`, `recovery.pcapng`) mở được trực tiếp bằng **Wireshark / TShark**.

---

## 2. Sơ đồ Kiến trúc Mạng (Dual-Subnet Topology)

```text
  [ INTERNAL_NET: 192.168.0.0/24 ]                [ EXTERNAL_NET: 10.10.0.0/24 ]
  (Phân vùng Máy chủ DHCP Hợp lệ)                 (Broadcast Domain: Client & Attacker)

  +------------------------------+                +------------------------------------+
  |        dhcpserver            |                |              client                |
  | (Linux ISC DHCP Server)      |                | (Ubuntu DHCP Client - Victim)      |
  | IP : 192.168.0.100/24        |                | MAC: 02:42:0a:0a:00:32             |
  | MAC: 02:42:c0:a8:00:64       |                | Pool hợp lệ: 10.10.0.100 - .130    |
  | Option 54: 192.168.0.100     |                +-----------------+------------------+
  | Option 3 : 10.10.0.1         |                                  |
  | Option 6 : 192.168.0.100     |                                  | (Broadcast L2)
  +--------------+---------------+                                  |
                 |                                                  |
                 | INTERNAL: 192.168.0.1          EXTERNAL: 10.10.0.1
                 | (02:42:c0:a8:00:01)            (02:42:0a:0a:00:01)
                 |                                                  |
         +-------+--------------------------------------------------+-------+
         |                            dhcprelay                             |
         |  1) ISC DHCP Relay (dhcrelay -4 -i eth0 -i eth1 192.168.0.100)   |
         |  2) Scapy DHCP Fingerprinting & ARP Monitoring Sensor            |
         |  3) Real-Time Web Dashboard (http://10.10.0.1:5000)              |
         |  4) Wireshark / TShark PCAPNG Recorder (/home/ubuntu/captures)   |
         +----------------------------------------------------------+-------+
                                                                    |
                                                                    | (Broadcast L2)
                                                                    |
                                                  +-----------------+------------------+
                                                  |             attacker               |
                                                  | (Kali Rogue DHCP Server - Scapy)   |
                                                  | IP : 10.10.0.20/24 (eth0)          |
                                                  | MAC: 02:42:0a:0a:00:14             |
                                                  | Rogue Option 54: 10.10.0.20        |
                                                  | Rogue yiaddr   : 10.10.0.200       |
                                                  | Rogue Option 3 : 10.10.0.20 (GW)   |
                                                  | Rogue Option 6 : 10.10.0.20 (DNS)  |
                                                  +------------------------------------+
```

---

## 3. Yêu cầu Hệ thống

- **Hệ điều hành:** Ubuntu 20.04 / 22.04 / 24.04 LTS (`x86_64`)
- **Cấu hình khuyến nghị:** Tối thiểu 2 vCPU (khuyến nghị 4 vCPU), 4 GB RAM (khuyến nghị 8 GB RAM), 10 GB dung lượng đĩa trống.
- **Phần mềm nền tảng:**
  - Docker Engine `>= 20.10` (đã test trên `Docker 27.0.3`)
  - Labtainers `>= v1.4` (`LABTAINER_DIR=/home/student/labtainer/trunk`)

> **Khả năng chạy độc lập 100%:** Bài lab đã đóng gói sẵn toàn bộ cấu hình mạng (`INTERNAL_NET`, `EXTERNAL_NET`) trong `config/start.config` và toàn bộ thư viện (`Scapy`, `PyYAML`, `Wireshark`, `TShark`, `dumpcap`, `isc-dhcp-server`, `isc-dhcp-relay`) bên trong 4 Docker images trên Docker Hub `zeus183`. Người dùng mới không cần cài đặt trước `labtainer-network-base` hay bất kỳ gói Python phụ trợ nào.

---

## 4. Danh sách Container & Docker Hub Images

Trang Docker Hub tổng hợp chính: **[https://hub.docker.com/r/zeus183/dhcp-rogue-monitor](https://hub.docker.com/r/zeus183/dhcp-rogue-monitor)**

| Container | Image chuẩn Labtainers (`REGISTRY zeus183`) | Tag trên Repo tổng hợp | Địa chỉ IP & MAC | Vai trò |
| :--- | :--- | :--- | :--- | :--- |
| **`dhcpserver`** | `zeus183/dhcp-rogue-monitor.dhcpserver.student:latest` | `zeus183/dhcp-rogue-monitor:dhcpserver` | `192.168.0.100`<br>`02:42:c0:a8:00:64` | Máy chủ ISC DHCP hợp lệ |
| **`dhcprelay`** | `zeus183/dhcp-rogue-monitor.dhcprelay.student:latest` | `zeus183/dhcp-rogue-monitor:dhcprelay` | `192.168.0.1` / `10.10.0.1`<br>`02:42:0a:0a:00:01` | DHCP Relay + Scapy Sensor + Dashboard + TShark |
| **`attacker`** | `zeus183/dhcp-rogue-monitor.attacker.student:latest` | `zeus183/dhcp-rogue-monitor:attacker` | `10.10.0.20`<br>`02:42:0a:0a:00:14` | Máy tấn công Kali chạy Rogue DHCP Server |
| **`client`** | `zeus183/dhcp-rogue-monitor.client.student:latest` | `zeus183/dhcp-rogue-monitor:client` | Động qua DHCP<br>`02:42:0a:0a:00:32` | Máy trạm Ubuntu Client |

---

## 5. Công nghệ Sử dụng

- **Ngôn ngữ & Thư viện:** Python 3, Scapy (`DHCP`, `BOOTP`, `ARP`, `Ether`, `IP`, `UDP`), PyYAML (`trusted_servers.yaml`, `detection.yaml`).
- **Hạ tầng DHCP:** Linux ISC DHCP Server (`isc-dhcp-server`), ISC DHCP Relay (`isc-dhcp-relay`), ISC DHCP Client (`dhclient`).
- **Phân tích & Bắt gói tin:** Wireshark GUI, TShark, `dumpcap` (định dạng chuẩn `PCAPNG`).
- **Giao diện Giám sát:** Web Dashboard Python (`http://10.10.0.1:5000`) kèm REST JSON APIs (`/api/summary`, `/api/servers`, `/api/alerts`, `/api/arp`, `/api/events`).

---

## 6. Cài đặt (`imodule`) và Khởi chạy Bài Lab

### Bước 1: Import module bằng lệnh `imodule` chuẩn của Labtainers
Từ thư mục `labtainer-student` trên máy ảo Labtainers:
```bash
cd ~/labtainer/trunk/scripts/labtainer-student
imodule https://github.com/ldanh54321-stack/dhcp-rogue-monitor/releases/download/v1.0.0/dhcp-rogue-monitor.tar
```
*(Hoặc import từ link raw nhánh `main`: `imodule https://github.com/ldanh54321-stack/dhcp-rogue-monitor/raw/refs/heads/main/dhcp-rogue-monitor.tar`)*.

### Bước 2: Khởi chạy bài lab
```bash
labtainer dhcp-rogue-monitor
```
*(Nếu muốn khởi tạo lại từ đầu/reset bài lab: `labtainer -r dhcp-rogue-monitor`)*.

---

## 7. Hướng dẫn Thực hành Chi tiết trên 4 Terminal

### Giai đoạn 1: Kiểm tra DHCP Bình thường (Baseline) & Bắt gói `normal.pcapng`

1. **Trên terminal `dhcpserver`** — Kiểm tra dịch vụ ISC DHCP Server hợp lệ:
   ```bash
   pgrep -a dhcpd
   cat /etc/dhcp/dhcpd.conf
   ```
2. **Trên terminal `dhcprelay`** — Kiểm tra Sensor/Dashboard tự động chạy và bật `dumpcap` ghi `normal.pcapng`:
   ```bash
   pgrep -af "dhcrelay|dhcp_sniffer.py|dashboard/app.py"
   cat /etc/dhcp-rogue-monitor/trusted_servers.yaml
   EXT_IF=$(ip -o -4 addr show | awk '$4 ~ /^10\.10\.0\./ {print $2; exit}')
   sudo dumpcap -i "$EXT_IF" -f "(udp port 67 or udp port 68) or arp" -w /home/ubuntu/captures/normal.pcapng &
   ```
3. **Trên terminal `client`** — Xin cấp phát IP động hợp lệ:
   ```bash
   ip addr show eth0
   sudo dhclient -v eth0
   ip addr show eth0
   ip route show
   ```
4. **Trên terminal `dhcprelay`** — Dừng bắt gói và xem kết quả Fingerprinting:
   ```bash
   sudo pkill -INT dumpcap
   tshark -r /home/ubuntu/captures/normal.pcapng
   cat /var/log/dhcp-rogue-monitor/servers.json
   ```

---

### Giai đoạn 2: Chạy Rogue DHCP Server & Phát hiện bằng DHCP Fingerprinting

1. **Trên terminal `dhcprelay`** — Bắt đầu ghi gói tin giai đoạn tấn công vào `rogue_attack.pcapng`:
   ```bash
   EXT_IF=$(ip -o -4 addr show | awk '$4 ~ /^10\.10\.0\./ {print $2; exit}')
   sudo dumpcap -i "$EXT_IF" -f "(udp port 67 or udp port 68) or arp" -w /home/ubuntu/captures/rogue_attack.pcapng &
   ```
2. **Trên terminal `attacker`** — Gán IP `10.10.0.20/24` và khởi chạy trực tiếp Rogue DHCP Server:
   ```bash
   sudo ip addr add 10.10.0.20/24 dev eth0 2>/dev/null || true
   sudo ip link set eth0 up
   sudo python3 /usr/local/bin/rogue_dhcp.py --iface eth0
   ```
   *(Đợi dòng `ROGUE_SERVER_STARTED` xuất hiện trên màn hình `attacker`, giữ nguyên tiến trình đang chạy)*.
3. **Trên terminal `client`** — Giải phóng và xin cấp lại IP khi có Rogue Server:
   ```bash
   sudo dhclient -r eth0
   sudo dhclient -v eth0
   ip addr show eth0
   ip route show
   ```
4. **Trên terminal `dhcprelay`** — Dừng `dumpcap` và kiểm tra cảnh báo phát hiện (`HIGH` / `CRITICAL`):
   ```bash
   sudo pkill -INT dumpcap
   tshark -r /home/ubuntu/captures/rogue_attack.pcapng
   grep -E "SEVERITY=(HIGH|CRITICAL)" /var/log/dhcp_rogue_detection.log
   cat /var/log/dhcp-rogue-monitor/servers.json
   ```

---

### Giai đoạn 3: Giám sát ARP & Sử dụng Web Dashboard

Trên terminal **`dhcprelay`**:
```bash
# 1. Xem bảng ánh xạ IP - MAC thu thập bởi Scapy ARP Monitor
cat /var/log/dhcp-rogue-monitor/arp_table.json

# 2. Truy vấn dữ liệu JSON thời gian thực từ Web Dashboard (cổng 5000)
wget -qO- http://127.0.0.1:5000/api/summary | python3 -m json.tool | head -n 45
```

---

### Giai đoạn 4: Dừng Rogue DHCP Server & Khôi phục (`recovery.pcapng`)

1. **Trên terminal `attacker`** — Nhấn **`Ctrl + C`** để dừng ngay tiến trình `rogue_dhcp.py`.
2. **Trên terminal `dhcprelay`** — Bắt đầu ghi gói tin giai đoạn phục hồi vào `recovery.pcapng`:
   ```bash
   EXT_IF=$(ip -o -4 addr show | awk '$4 ~ /^10\.10\.0\./ {print $2; exit}')
   sudo dumpcap -i "$EXT_IF" -f "(udp port 67 or udp port 68) or arp" -w /home/ubuntu/captures/recovery.pcapng &
   ```
3. **Trên terminal `client`** — Giải phóng lease độc hại và xin cấp lại IP hợp lệ:
   ```bash
   sudo dhclient -r eth0
   sudo dhclient -v eth0
   ip addr show eth0
   ip route show
   ```
4. **Trên terminal `dhcprelay`** — Dừng `dumpcap` và kiểm tra đủ 3 file PCAPNG:
   ```bash
   sudo pkill -INT dumpcap
   ls -lh /home/ubuntu/captures/*.pcapng
   ```

---

### Giai đoạn 5: Phân tích PCAP bằng Wireshark, Xuất Báo cáo & Chấm điểm (`checkwork`)

1. **Trên terminal `dhcprelay`** — Xuất báo cáo tổng hợp và (tùy chọn) mở Wireshark GUI:
   ```bash
   python3 /usr/local/bin/generate-report.py
   # Mở Wireshark phân tích trực quan (tùy chọn):
   wireshark /home/ubuntu/captures/rogue_attack.pcapng &
   ```
2. **Trên terminal máy Host** — Chấm điểm tự động với `checkwork`:
   ```bash
   cd ~/labtainer/trunk/scripts/labtainer-student
   checkwork dhcp-rogue-monitor
   ```
   Tất cả **7/7 mục tiêu** (`client_baseline_ip`, `sensor_active`, `rogue_attack_run`, `rogue_detected`, `pcap_captured`, `client_recovered`, `report_generated`) đạt **`Y`**.

---

## 8. Dừng Bài Lab & Xử lý Lỗi Thường gặp

- **Dừng bài lab:**
  ```bash
  cd ~/labtainer/trunk/scripts/labtainer-student
  stoplab dhcp-rogue-monitor
  ```
- **Xử lý lỗi thường gặp:**
  - *Lỗi chạy `./labtainer` từ bên trong thư mục `bin/`*: Luôn đứng tại `~/labtainer/trunk/scripts/labtainer-student` rồi gọi `labtainer dhcp-rogue-monitor`.
  - *Kiểm tra lại Sensor hoặc Dashboard trên `dhcprelay`*: Chạy `/usr/local/bin/sensor-start.sh` và `/usr/local/bin/dashboard-start.sh` nếu bạn lỡ tay dừng tiến trình ngầm.
